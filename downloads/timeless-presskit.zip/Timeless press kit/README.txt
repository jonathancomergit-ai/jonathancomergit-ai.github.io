TIMELESS - press kit
====================

Everything in here is free to use in coverage, videos, streams and
articles about Timeless. No need to ask first.

  logo/         the Timeless logo, transparent background
  art/          title art, key art (600x900) and a banner
  screenshots/  in-game screenshots (1600 wide, except the lore scene at 1280x720)

Full fact sheet, description and contact: https://jonjoe1001.dev/presskit.html
Steam: https://store.steampowered.com/app/4437000/Timeless/

Art by KTB. Please don't edit the art itself (cropping and
resizing to fit your layout is fine).
