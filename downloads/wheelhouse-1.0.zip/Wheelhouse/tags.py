"""Genre + player-mode tagging.

Two sources, because neither alone is enough:
  * Steam store appdetails -> `categories`, which state definitively whether a
    game is Single-player only, Co-op, PvP, MMO. This is what stops the wheel
    offering a solo city-builder to five people.
  * SteamSpy -> community tags ("City Builder", "Automation", "Roguelike"),
    which are far more useful than Steam's coarse genres ("Simulation").

Steam publishes no max-player number anywhere, so player COUNT is derived from
modes and can be overridden by hand per game.
"""
import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import re

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "cache")
TAGFILE = os.path.join(CACHE, "tags.json")
UA = {"User-Agent": "Mozilla/5.0 (compatible; SteamWheel/1.0)"}

# Steam's store API tolerates roughly 200 requests per 5 minutes.
PLAYER_TAG = re.compile(r"(\d+)\s*player", re.I)

STEAM_DELAY = 1.6
SPY_DELAY = 1.1


# ------------------------------------------------------------------ format

# Genre and seat count answer "what is it" and "does everyone fit". A bracket
# needs a third answer: does playing this produce a winner, in one sitting? A
# co-op story game passes both other tests and fails this one, which is how
# Baldur's Gate 3 ends up in a tournament asking who won.
#
# Steam's own PvP category is the strongest signal there is - Valve-supplied,
# not crowd-guessed - so it carries the most weight. Everything else nudges.

PVP_CATS = {"PvP", "Online PvP", "Shared/Split Screen PvP"}
COOP_CATS = {"Co-op", "Online Co-op", "Shared/Split Screen Co-op"}

# tags that mean someone wins
VS_TAGS = {
    "pvp": 3, "competitive": 3, "1v1": 3, "fighting": 3, "2d fighter": 3,
    "3d fighter": 3, "esports": 3, "deathmatch": 3, "trivia": 3, "chess": 3,
    "party game": 3, "arena shooter": 2, "battle royale": 2, "auto battler": 2,
    "card battler": 2, "party": 2, "local multiplayer": 2, "split screen": 2,
    "racing": 2, "sports": 2, "football (soccer)": 2, "board game": 2,
    "score attack": 2, "team-based": 1, "tactical": 1, "turn-based combat": 1,
    "arcade": 1, "platformer": 1,
}

# tags that mean a match will not finish tonight
LONG_TAGS = {
    "mmorpg": -4, "massively multiplayer": -4, "grand strategy": -4, "4x": -3,
    "open world survival craft": -3, "city builder": -3, "colony sim": -3,
    "idler": -3, "clicker": -3, "base building": -2, "farming sim": -2,
    "automation": -2, "persistent": -2, "sandbox": -1, "open world": -1,
    "survival": -1, "crafting": -1, "roguelike": -1, "exploration": -1,
}

# tags that mean there is no winner because the point is the story
STORY_TAGS = {
    "story rich": -4, "walking simulator": -4, "interactive fiction": -4,
    "visual novel": -4, "narrative": -3, "choices matter": -3, "emotional": -2,
    "relaxing": -2, "cozy": -2, "atmospheric": -1, "wholesome": -1, "puzzle": -1,
}

VERSUS_AT = 3.0    # at or above: someone wins by playing it as intended
MIXED_AT = 0.0     # at or above: playable as a match, but needs a house rule

# What "winning" means for a game with no built-in versus mode. Picked off the
# game's own tags so the rule suits it, rather than one generic fallback.
WIN_RULES = [
    (("racing", "driving"), "Fastest lap"),
    (("score attack", "arcade", "shoot em up", "bullet hell"), "Highest score"),
    (("puzzle", "escape room", "point & click"), "First to solve it"),
    (("platformer", "speedrun", "precision platformer"), "Furthest in 10 minutes"),
    (("survival", "horror", "roguelike", "rogue-lite"), "Last one standing"),
    (("cooking", "management", "simulation"), "Best score on one level"),
]
DEFAULT_WIN_RULE = "Best run in a fixed time"


# ------------------------------------------------------------- categories

# Curated buckets, matched against SteamSpy tags (and Steam genres as backup).
# Order matters only for display; a game can land in several.
CATEGORY_RULES = [
    ("City Builder",   ["city builder", "city building", "town builder"]),
    ("Automation",     ["automation", "factory", "programming", "base building", "base-building"]),
    ("Roguelike",      ["roguelike", "roguelite", "rogue-like", "rogue-lite", "run-based"]),
    ("Horror",         ["horror", "psychological horror", "survival horror", "lovecraftian"]),
    ("Puzzle",         ["puzzle", "logic", "puzzle platformer", "physics"]),
    ("Shooter",        ["fps", "shooter", "first-person shooter", "third-person shooter",
                        "shoot 'em up", "looter shooter", "tactical shooter", "arena shooter"]),
    ("Story",          ["story rich", "narrative", "visual novel", "interactive fiction",
                        "choices matter", "walking simulator", "adventure"]),
    ("Survival",       ["survival", "open world survival craft", "crafting", "hunger"]),
    ("Strategy",       ["strategy", "rts", "real-time strategy", "turn-based strategy",
                        "grand strategy", "4x", "tower defense"]),
    ("Simulation",     ["simulation", "life sim", "farming sim", "immersive sim", "sandbox"]),
    ("Management",     ["management", "tycoon", "economy", "resource management",
                        "colony sim", "god game"]),
    ("RPG",            ["rpg", "jrpg", "crpg", "action rpg", "party-based rpg", "dungeon crawler"]),
    ("Platformer",     ["platformer", "precision platformer", "2d platformer", "metroidvania"]),
    ("Racing",         ["racing", "driving", "automobile sim", "motocross"]),
    ("Sports",         ["sports", "football", "basketball", "golf", "soccer", "skateboarding"]),
    ("Fighting",       ["fighting", "beat 'em up", "brawler", "martial arts", "pvp"]),
    ("Party",          ["party game", "funny", "comedy", "social deduction", "local multiplayer",
                        "4 player local", "party-based"]),
    ("Card & Board",   ["card game", "board game", "deckbuilding", "deckbuilder", "tabletop",
                        "trading card game"]),
    ("Sandbox",        ["sandbox", "building", "moddable", "open world"]),
    ("Co-op",          ["co-op", "online co-op", "co-op campaign", "multiplayer"]),
]

CATEGORY_NAMES = [c for c, _ in CATEGORY_RULES]

# Steam store category strings that describe how many people can play.
MODE_MAP = {
    "Single-player": "single",
    "Multi-player": "multi",
    "PvP": "pvp",
    "Online PvP": "pvp",
    "LAN PvP": "pvp",
    "Shared/Split Screen PvP": "local",
    "Co-op": "coop",
    "Online Co-op": "coop",
    "LAN Co-op": "coop",
    "Shared/Split Screen Co-op": "local",
    "Shared/Split Screen": "local",
    "Cross-Platform Multiplayer": "multi",
    "MMO": "mmo",
}


# ------------------------------------------------------------------ fetch

def _get(url, timeout=25):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as f:
        return json.loads(f.read().decode("utf-8", "replace"))


def fetch_steam(appid):
    """genres + store categories. Returns None when the app is delisted."""
    url = ("https://store.steampowered.com/api/appdetails?appids=%d&l=english" % appid)
    try:
        d = _get(url)
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError):
        return None
    entry = (d or {}).get(str(appid)) or {}
    if not entry.get("success"):
        return None
    data = entry.get("data") or {}
    return {
        "genres": [g.get("description", "") for g in data.get("genres", [])],
        "store_cats": [c.get("description", "") for c in data.get("categories", [])],
        "type": data.get("type", ""),
    }


def fetch_spy(appid):
    """SteamSpy community tags, most-voted first."""
    try:
        d = _get("https://steamspy.com/api.php?request=appdetails&appid=%d" % appid)
    except (urllib.error.URLError, json.JSONDecodeError, TimeoutError):
        return None
    tags = (d or {}).get("tags")
    if isinstance(tags, dict):
        return [t for t, _ in sorted(tags.items(), key=lambda kv: -kv[1])][:20]
    if isinstance(tags, list):
        return tags[:20]
    return []


# --------------------------------------------------------------- classify

def score_format(rec):
    """Returns (format, versus_score, win_condition).

    format is one of: versus, mixed, unfit, solo.
    """
    cats = set(rec.get("store_cats") or [])
    tags = [t.lower() for t in (rec.get("tags") or [])]

    has_pvp = bool(cats & PVP_CATS)
    has_coop = bool(cats & COOP_CATS)
    if not (has_pvp or has_coop or "Multi-player" in cats):
        return "solo", 0.0, ""

    score = 0.0
    if has_pvp:
        # A game listing online PvP AND local PvP AND split-screen PvP is built
        # around beating someone; one lone PvP mode is a weaker claim.
        score += 5 + 0.8 * (len(cats & PVP_CATS) - 1)
    elif has_coop:
        # Co-op with no PvP anywhere is the whole problem: four seats, no winner.
        score -= 4

    # Tags near the top of the list are the ones most players agreed on.
    for i, t in enumerate(tags[:20]):
        weight = 1.0 if i < 6 else 0.6
        for table in (VS_TAGS, LONG_TAGS, STORY_TAGS):
            if t in table:
                score += table[t] * weight

    # A game Valve marks PvP is a versus game even if it is also a big open
    # world - ShellShock Live should not be demoted by a Massively Multiplayer
    # tag. Session-length doubts can hold it at "mixed"; they cannot sink it.
    if has_pvp and score < MIXED_AT:
        score = MIXED_AT

    # Without a versus mode there is nothing to win by playing it as intended,
    # however party-flavoured the tags are. Those games can still make a fine
    # bracket - they just need a house rule, which is exactly "mixed".
    if score >= VERSUS_AT and has_pvp:
        return "versus", round(score, 1), ""
    if score >= MIXED_AT:
        return "mixed", round(score, 1), win_rule(tags)
    return "unfit", round(score, 1), ""


def win_rule(tags):
    """How you would decide a winner in a game that has no versus mode."""
    for keys, rule in WIN_RULES:
        if any(k in tags for k in keys):
            return rule
    return DEFAULT_WIN_RULE


def classify(rec):
    """Turn raw tag data into {cats, modes, solo_only, max_players}."""
    tags = [t.lower() for t in (rec.get("tags") or [])]
    genres = [g.lower() for g in (rec.get("genres") or [])]
    haystack = tags + genres

    cats = []
    for name, keys in CATEGORY_RULES:
        if any(k in haystack for k in keys):
            cats.append(name)

    modes = set()
    for c in rec.get("store_cats") or []:
        m = MODE_MAP.get(c)
        if m:
            modes.add(m)

    multi = bool(modes & {"multi", "coop", "pvp", "local", "mmo"})
    solo_only = ("single" in modes or not modes) and not multi

    # No Steam API exposes a max-player figure, so derive one. A few community
    # tags state it outright ("4 Player Local") - trust those over the guess.
    stated = []
    for t in tags:
        m = PLAYER_TAG.search(t)
        if m:
            n = int(m.group(1))
            if 1 <= n <= 64:
                stated.append(n)

    if solo_only:
        cap, basis = 1, "solo"
    elif stated:
        cap, basis = max(stated), "tag"
    elif "mmo" in modes:
        cap, basis = 12, "guess"
    elif modes & {"multi", "pvp"}:
        cap, basis = 8, "guess"
    else:
        cap, basis = 4, "guess"

    fmt, vscore, win = score_format(rec)
    if solo_only:
        fmt, win = "solo", ""

    return {
        "cats": cats or ["Other"],
        "modes": sorted(modes),
        "solo_only": solo_only,
        "max_players": cap,
        "cap_basis": basis,
        "format": fmt,
        "versus_score": vscore,
        "win_cond": win,
    }


def reclassify(db):
    """Recompute categories/caps from already-fetched raw data. Cheap - no HTTP."""
    for rec in (db.get("apps") or {}).values():
        rec.update(classify(rec))
    return db


# ------------------------------------------------------------------ store

_lock = threading.Lock()

def load():
    try:
        with open(TAGFILE, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return {"apps": {}, "updated": 0, "progress": None}


def save(db):
    os.makedirs(CACHE, exist_ok=True)
    tmp = TAGFILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(db, fh)
    os.replace(tmp, TAGFILE)


def enrich(appids, on_progress=None, force=False):
    """Fill in tag data for appids, skipping ones already cached.

    Slow on purpose - both APIs are rate limited. Writes incrementally so the
    work survives a crash and the UI can show progress.
    """
    db = load()
    apps = db.setdefault("apps", {})
    todo = [a for a in appids if force or str(a) not in apps]
    total = len(todo)
    done = 0

    for appid in todo:
        rec = {"appid": appid}
        s = fetch_steam(appid)
        time.sleep(STEAM_DELAY)
        if s:
            rec.update(s)
        spy = fetch_spy(appid)
        time.sleep(SPY_DELAY)
        if spy is not None:
            rec["tags"] = spy
        rec.update(classify(rec))

        with _lock:
            apps[str(appid)] = rec
            done += 1
            db["updated"] = int(time.time())
            db["progress"] = {"done": done, "total": total, "running": done < total}
            if done % 10 == 0 or done == total:
                save(db)
        if on_progress:
            on_progress(done, total, rec)

    db["progress"] = {"done": done, "total": total, "running": False}
    save(db)
    return db
