/* The wheel: weighted canvas slices, capsule art, easing physics, tick audio. */

const TAU = Math.PI * 2;

/* ------------------------------------------------------------------ audio */

/* Every entry point is guarded. These run inside the spin's animation callback,
 * and an exception escaping there would leave the spin promise unsettled - the
 * wheel would hang mid-spin. A machine with no audio device still gets to play. */
const Audio2 = {
  ctx: null,
  muted: false,
  dead: false,

  wake() {
    if (this.dead) return null;
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) { this.dead = true; return null; }
        this.ctx = new AC();
      }
      if (this.ctx.state === "suspended") this.ctx.resume();
      return this.ctx;
    } catch (e) {
      this.dead = true;
      return null;
    }
  },

  blip(freq, dur, type, gain) {
    if (this.muted || this.dead) return;
    try {
      const ac = this.wake();
      if (!ac) return;
      const osc = ac.createOscillator();
      const amp = ac.createGain();
      osc.type = type || "square";
      osc.frequency.value = freq;
      amp.gain.setValueAtTime(0, ac.currentTime);
      amp.gain.linearRampToValueAtTime(gain === undefined ? 0.05 : gain, ac.currentTime + 0.004);
      amp.gain.exponentialRampToValueAtTime(0.0001, ac.currentTime + dur);
      osc.connect(amp).connect(ac.destination);
      osc.start();
      osc.stop(ac.currentTime + dur + 0.02);
    } catch (e) {
      this.dead = true;
    }
  },

  tick() { this.blip(1150 + Math.random() * 130, 0.035, "square", 0.035); },
  land() { [523, 659, 784, 1047].forEach((f, i) => setTimeout(() => this.blip(f, 0.3, "triangle", 0.09), i * 95)); },
  bust() { [330, 262, 196].forEach((f, i) => setTimeout(() => this.blip(f, 0.22, "sawtooth", 0.055), i * 85)); },
};

/* ------------------------------------------------------------------ colour */

/* Steam-native palette: cool blues with a couple of warm accents for contrast. */
const SLICE_COLORS = [
  "#16293d", "#20455f", "#0e1d2e", "#295a74", "#132639",
  "#1b3a52", "#0a1420", "#235068", "#17324a", "#1e4159",
];

function sliceColor(slice, i) {
  if (slice.virtual === "golden") return "#6d5518";
  if (slice.virtual === "cursed") return "#471a27";
  if (slice.virtual === "wildcard") return "#38224a";
  return SLICE_COLORS[i % SLICE_COLORS.length];
}

/** Lighten (amt > 0) or darken (amt < 0) a #rrggbb by a 0..1 fraction. */
function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16);
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((c) =>
    Math.max(0, Math.min(255, Math.round(amt >= 0 ? c + (255 - c) * amt : c * (1 + amt))))
  );
  return "#" + ch.map((v) => v.toString(16).padStart(2, "0")).join("");
}

/** #rrggbb -> rgba() at the given alpha. */
function rgba(hex, a) {
  const n = parseInt(hex.slice(1), 16);
  return "rgba(" + ((n >> 16) & 255) + "," + ((n >> 8) & 255) + "," + (n & 255) + "," + a + ")";
}

/* ------------------------------------------------------------------- art */

const artCache = new Map();

function art(appid) {
  if (appid < 0) return null;
  if (artCache.has(appid)) return artCache.get(appid);
  const img = new Image();
  img.src = "/api/img/" + appid;
  const rec = { img, ok: false };
  img.onload = () => { rec.ok = img.naturalWidth > 2; };
  img.onerror = () => { rec.ok = false; };
  artCache.set(appid, rec);
  return rec;
}

/* ------------------------------------------------------------------- text */

/* Trim to the space actually available, measured for real - character counts
 * guess wrong and run the text under the hub. Font must be set on ctx first. */
function fitText(ctx, text, maxW) {
  if (ctx.measureText(text).width <= maxW) return text;
  while (text.length > 3 && ctx.measureText(text + "…").width > maxW) {
    text = text.slice(0, -1);
  }
  return text.trimEnd() + "…";
}

/* ------------------------------------------------------------------ easing */

/* Long, slow tail so the last few slices crawl past the pointer. */
function easeSpin(t) {
  return 1 - Math.pow(1 - t, 4.6);
}

/* ------------------------------------------------------------------- Wheel */

class Wheel {
  constructor(canvas) {
    this.cv = canvas;
    this.ctx = canvas.getContext("2d");
    this.slices = [];
    this.rot = 0;
    this.spinning = false;
    this.blackout = false;
    this.lastTickIndex = -1;
    this.onTick = null;
    this._raf = null;
    this._reflow = null;
    this.render();
  }

  /** slices: [{appid, name, weight, virtual}] - angles are derived from weight. */
  setSlices(list, animate) {
    /* Kill any reflow still in flight. Its `from` array indexes the OLD slice
     * set, so one late frame would write stale angles over the new one and tear
     * a gap in the wheel. */
    if (this._reflow) {
      cancelAnimationFrame(this._reflow);
      this._reflow = null;
    }
    const prev = new Map(this.slices.map((s) => [s.appid, s]));
    const total = list.reduce((n, s) => n + (s.weight || 1), 0) || 1;
    let a = 0;
    this.slices = list.map((s, i) => {
      const span = ((s.weight || 1) / total) * TAU;
      const t0 = a, t1 = a + span;
      a = t1;
      const old = prev.get(s.appid);
      return {
        ...s,
        color: sliceColor(s, i),
        t0, t1,
        a0: animate && old ? old.a0 : t0,
        a1: animate && old ? old.a1 : t1,
      };
    });
    if (animate) this._animateReflow();
    else this.render();
  }

  _animateReflow() {
    if (this._reflow) cancelAnimationFrame(this._reflow);
    const start = performance.now();
    const from = this.slices.map((s) => [s.a0, s.a1]);
    const step = (now) => {
      const t = Math.min(1, (now - start) / 520);
      const e = 1 - Math.pow(1 - t, 3);
      this.slices.forEach((s, i) => {
        s.a0 = from[i][0] + (s.t0 - from[i][0]) * e;
        s.a1 = from[i][1] + (s.t1 - from[i][1]) * e;
      });
      this.render();
      if (t < 1) this._reflow = requestAnimationFrame(step);
      else this._reflow = null;
    };
    this._reflow = requestAnimationFrame(step);
  }

  /** Which slice is under the pointer right now. */
  indexAtPointer() {
    const want = ((-Math.PI / 2 - this.rot) % TAU + TAU) % TAU;
    for (let i = 0; i < this.slices.length; i++) {
      const s = this.slices[i];
      if (want >= s.a0 && want < s.a1) return i;
    }
    return this.slices.length - 1;
  }

  /* --------------------------------------------------------------- render */

  render() {
    const ctx = this.ctx;
    const W = this.cv.width, H = this.cv.height;
    const cx = W / 2, cy = H / 2;
    const R = Math.min(cx, cy) - 30;

    ctx.clearRect(0, 0, W, H);

    /* --- bezel: a brushed metal ring, lit from above --- */
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R + 26, 0, TAU);
    const rim = ctx.createLinearGradient(0, cy - R - 26, 0, cy + R + 26);
    rim.addColorStop(0.00, "#8fd6dc");
    rim.addColorStop(0.16, "#37697f");
    rim.addColorStop(0.42, "#0d1620");
    rim.addColorStop(0.58, "#080f17");
    rim.addColorStop(0.84, "#2a5468");
    rim.addColorStop(1.00, "#6fb6c4");
    ctx.fillStyle = rim;
    ctx.fill();
    ctx.restore();

    /* seat the face into the bezel with a dark inner lip */
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R + 8, 0, TAU);
    ctx.fillStyle = "#03060b";
    ctx.fill();
    ctx.restore();

    if (!this.slices.length) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, TAU);
      ctx.fillStyle = "#0a121c";
      ctx.fill();
      ctx.fillStyle = "#5c6b78";
      ctx.font = "500 30px Arial";
      ctx.textAlign = "center";
      ctx.fillText("Add games from the Library", cx, cy - R * 0.42);
      ctx.restore();
      return;
    }

    const big = this.slices.length <= 26;
    const geo = this.slices.map((s) => {
      const a0 = s.a0 + this.rot, a1 = s.a1 + this.rot;
      const span = s.a1 - s.a0;
      return { s, a0, a1, span, mid: (a0 + a1) / 2, wide: span > 0.9 };
    });

    /* --- pass 1: wedges and capsule art --- */
    for (const g of geo) {
      const { s, a0, a1, span, mid } = g;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, R, a0, a1);
      ctx.closePath();

      /* lit toward the hub, sunk toward the rim - gives each wedge volume */
      const fill = ctx.createRadialGradient(cx, cy, R * 0.14, cx, cy, R);
      fill.addColorStop(0, shade(s.color, 0.13));
      fill.addColorStop(0.66, s.color);
      fill.addColorStop(1, shade(s.color, -0.17));
      ctx.fillStyle = fill;
      ctx.fill();

      /* Capsule art fills the wedge itself: the slice is the frame, so the
       * picture is cut to the pie shape rather than floating inside it. */
      if (span > 0.16 && !this.blackout) {
        const rec = art(s.appid);
        if (rec && rec.ok) {
          ctx.save();
          ctx.clip();
          ctx.translate(cx, cy);
          ctx.rotate(mid);

          /* Sized to run hub to rim, then zoomed just enough to cover the
           * chord as well. The cap matters on a near-empty wheel: a half-circle
           * wedge would otherwise demand a 4x blow-up, and wedge colour showing
           * at the outer corners reads far better than a blurred crop. */
          let w = R * 1.06, h = w * (215 / 460);
          const chord = 2 * R * Math.sin(Math.min(span, Math.PI) / 2);
          const need = chord / h;
          const zoom = Math.min(2.2, Math.max(1, need));
          w *= zoom; h *= zoom;
          ctx.globalAlpha = 0.9;
          ctx.drawImage(rec.img, R * 0.52 - w / 2, -h / 2, w, h);

          /* On a wide wedge the capsule cannot reach the corners without being
           * blown up into mush, so fade its long edges into the slice colour
           * instead. A hard horizontal cut across a pie slice looks like a bug;
           * a fade looks deliberate. */
          if (need > zoom * 1.02) {
            const fade = ctx.createLinearGradient(0, -h * 0.6, 0, h * 0.6);
            fade.addColorStop(0, rgba(s.color, 0.92));
            fade.addColorStop(0.3, rgba(s.color, 0));
            fade.addColorStop(0.7, rgba(s.color, 0));
            fade.addColorStop(1, rgba(s.color, 0.92));
            ctx.fillStyle = fade;
            ctx.fillRect(-R * 1.3, -R * 1.3, R * 2.6, R * 2.6);
          }

          /* Tint it back toward the slice colour. This keeps the wedge's own
           * identity, restores the lit-at-the-hub volume, and buys back the
           * contrast the label needs to stay readable over busy capsules. */
          ctx.globalAlpha = 1;
          const tint = ctx.createRadialGradient(0, 0, R * 0.14, 0, 0, R);
          tint.addColorStop(0, rgba(shade(s.color, 0.13), 0.62));
          tint.addColorStop(0.66, rgba(s.color, 0.4));
          tint.addColorStop(1, rgba(shade(s.color, -0.17), 0.66));
          ctx.fillStyle = tint;
          ctx.fillRect(-R * 1.3, -R * 1.3, R * 2.6, R * 2.6);
          ctx.restore();
        }
      }

      /* groove between wedges */
      ctx.strokeStyle = "rgba(4,8,12,.55)";
      ctx.lineWidth = 2.5;
      ctx.stroke();
      ctx.restore();
    }

    /* --- pass 2: dome gloss and rim vignette, beneath the text --- */
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, TAU);
    ctx.clip();

    const vig = ctx.createRadialGradient(cx, cy, R * 0.68, cx, cy, R);
    vig.addColorStop(0, "rgba(0,0,0,0)");
    vig.addColorStop(1, "rgba(0,0,0,.24)");
    ctx.fillStyle = vig;
    ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

    const gloss = ctx.createRadialGradient(
      cx - R * 0.30, cy - R * 0.46, R * 0.04,
      cx - R * 0.10, cy - R * 0.20, R * 1.25);
    gloss.addColorStop(0, "rgba(255,255,255,.10)");
    gloss.addColorStop(0.42, "rgba(255,255,255,.03)");
    gloss.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = gloss;
    ctx.fillRect(cx - R, cy - R, R * 2, R * 2);

    /* thin highlight riding the inside of the bezel */
    ctx.beginPath();
    ctx.arc(cx, cy, R - 2, 0, TAU);
    ctx.strokeStyle = "rgba(255,255,255,.10)";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();

    /* --- pass 3: labels, crisp on top of the glass --- */
    for (const g of geo) {
      const { s, span, mid, wide } = g;
      if (span <= 0.055) continue;

      ctx.save();
      ctx.translate(cx, cy);

      const size = Math.max(13, Math.min(30, span * 260, big ? 30 : 20));
      ctx.font = (s.virtual ? "700 " : "600 ") + size + "px Arial, sans-serif";
      ctx.fillStyle = s.virtual === "golden" ? "#ffdf7e"
        : s.virtual === "cursed" ? "#ff9db1"
        : s.virtual === "wildcard" ? "#d7aaff" : "#f2f7fb";
      ctx.shadowColor = "rgba(0,0,0,.95)";
      ctx.shadowBlur = 9;
      ctx.textBaseline = "middle";

      let text = this.blackout && !s.virtual ? "? ? ?" : (s.label || s.name);

      if (wide) {
        /* Few slices: sit the label upright in the middle of the wedge. */
        ctx.rotate(mid);
        ctx.translate(R * 0.6, 0);
        ctx.rotate(-mid);
        ctx.textAlign = "center";
        ctx.fillText(fitText(ctx, text, R * 0.62), 0, 0);
      } else {
        /* Slices on the left would read upside-down, so flip them and anchor
         * from the other end. Orientation follows screen position, so
         * everything is right-way-up once the wheel stops. */
        const flip = Math.cos(mid) < 0;
        ctx.rotate(mid);
        if (flip) ctx.rotate(Math.PI);
        ctx.textAlign = flip ? "left" : "right";
        const maxW = R - 26 - R * 0.17;
        ctx.fillText(fitText(ctx, text, maxW), flip ? -(R - 26) : R - 26, 0);
      }
      ctx.restore();
    }

    /* inner ring so the hub sits cleanly */
    ctx.save();
    ctx.beginPath();
    ctx.arc(cx, cy, R * 0.148, 0, TAU);
    ctx.strokeStyle = "rgba(102,192,244,.35)";
    ctx.lineWidth = 3;
    ctx.stroke();
    ctx.restore();
  }

  /* ----------------------------------------------------------------- spin */

  /** Spin so `index` ends under the pointer. Resolves when it stops. */
  spin(index, duration) {
    if (this.spinning) return Promise.resolve(null);
    this.spinning = true;
    Audio2.wake();

    const s = this.slices[index];
    /* land somewhere inside the slice, not dead centre - looks more real */
    const inset = (s.a1 - s.a0) * 0.22;
    const target = s.a0 + inset + Math.random() * ((s.a1 - s.a0) - inset * 2);

    const turns = 5 + Math.floor(Math.random() * 3);
    const from = this.rot;
    const base = -Math.PI / 2 - target;
    let to = base;
    while (to < from + turns * TAU) to += TAU;

    const dur = duration || 6200 + Math.random() * 1400;
    const start = performance.now();
    this.lastTickIndex = this.indexAtPointer();

    return new Promise((resolve) => {
      /* Whatever happens, the spin must finish and land on the chosen slice -
       * a stranded promise would freeze the wheel for the rest of the night. */
      const finish = () => {
        this.rot = ((to % TAU) + TAU) % TAU;
        try { this.render(); } catch (e) { /* nothing left to draw with */ }
        this.spinning = false;
        resolve(this.slices[index]);
      };

      const step = (now) => {
        try {
          const t = Math.min(1, (now - start) / dur);
          this.rot = from + (to - from) * easeSpin(t);
          this.render();

          const at = this.indexAtPointer();
          if (at !== this.lastTickIndex) {
            this.lastTickIndex = at;
            Audio2.tick();
            if (this.onTick) this.onTick(at);
          }

          if (t < 1) this._raf = requestAnimationFrame(step);
          else finish();
        } catch (e) {
          finish();
        }
      };
      this._raf = requestAnimationFrame(step);
    });
  }

  /** Weighted random index, honouring slice weights. */
  pickIndex() {
    const total = this.slices.reduce((n, s) => n + (s.t1 - s.t0), 0);
    let r = Math.random() * total;
    for (let i = 0; i < this.slices.length; i++) {
      r -= this.slices[i].t1 - this.slices[i].t0;
      if (r <= 0) return i;
    }
    return this.slices.length - 1;
  }
}
