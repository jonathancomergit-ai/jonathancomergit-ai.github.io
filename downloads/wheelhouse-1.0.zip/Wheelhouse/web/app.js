/* Wheelhouse - app controller: library, pool, modes, spins, overlays. */

const $ = (id) => document.getElementById(id);
const el = (sel, root) => (root || document).querySelector(sel);
const els = (sel, root) => [...(root || document).querySelectorAll(sel)];

const State = {
  games: [],
  members: [],
  byId: new Map(),
  pool: new Set(),
  party: 4,
  copyRule: "strict",
  rigged: null,
  survived: {},
  history: [],
  removed: new Set(),      // games already picked this session
  pendingRemoval: null,    // the pick waiting for the winner card to close
  doubleUsed: false,
  sources: [],
  warnings: [],
  tokenExpires: 0,
  copiesKnown: false,
  steamid: "",
  cats: new Set(),          // chosen categories; empty means "anything"
  allCats: [],              // [{name, count}] from the server
  capacityRule: "on",
  houseRules: false,        // tournament: allow games that need an agreed rule
  tagProgress: null,
  view: "picker",
  seats: 2,                 // tournament: players in one match
  tourney: null,            // the live bracket, see tournament.js
};

let wheel;
let bombTimer = null;
let bombLeft = 0;

/* ------------------------------------------------------------------- utils */

async function api(path, opts) {
  const res = await fetch(path, opts);
  if (!res.ok) throw new Error("HTTP " + res.status);
  return res.json();
}

function toast(msg, ms) {
  const t = $("toast");
  t.textContent = msg;
  t.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => { t.hidden = true; }, ms || 3200);
}

/* Everyone in the room reads the same screen, so people are always named -
 * nothing says "you", because the reader is not necessarily the account this
 * copy is set up under. */
let _memberMap = null, _memberMapFor = null;
function memberMap() {
  if (_memberMapFor !== State.members) {
    _memberMapFor = State.members;
    _memberMap = new Map(State.members.map((m) => [m.steamid, m]));
  }
  return _memberMap;
}

/** Steam persona for a SteamID, or "" when no real name is known for it. */
function nameFor(sid) {
  const m = memberMap().get(sid);
  /* Without a Web API key the "name" is just the SteamID again - that is not
   * a name, so callers get a blank and can fall back to something honest. */
  return m && m.name && m.name !== sid ? m.name : "";
}

function ownerNames(g) {
  return (g.owners || []).map((s) => nameFor(s) || "a family member");
}

function fmtMins(m) {
  if (!m) return "never";
  const h = m / 60;
  return h < 1 ? Math.round(m) + "m" : (h < 10 ? h.toFixed(1) : Math.round(h)) + "h";
}

/** Everyone connected to a game - owners and anyone with time on it. */
function playerRows(g) {
  const map = memberMap();
  const by = g.by_player || {};
  const ids = new Set([...(g.owners || []), ...Object.keys(by)]);
  return [...ids].map((sid) => {
    const m = map.get(sid);
    const named = nameFor(sid);
    return {
      sid,
      name: named || "a family member",
      named: !!named,
      mins: by[sid] || 0,
      /* no playtime AND their profile hides it - "never" would be a lie */
      hidden: !by[sid] && m && m.playtime_status && m.playtime_status !== "ok",
      owner: (g.owners || []).includes(sid),
    };
  }).sort((a, b) => b.mins - a.mins || a.name.localeCompare(b.name));
}

/** Which slice sits under a click on the wheel canvas. */
function sliceAtEvent(ev) {
  const cv = $("wheel");
  const r = cv.getBoundingClientRect();
  const x = (ev.clientX - r.left) / r.width - 0.5;
  const y = (ev.clientY - r.top) / r.height - 0.5;
  if (Math.hypot(x, y) > 0.5 || Math.hypot(x, y) < 0.15) return null;
  const ang = ((Math.atan2(y, x) - wheel.rot) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
  return wheel.slices.find((s) => ang >= s.a0 && ang < s.a1) || null;
}

/** Capsule art is best-effort: a missing header must not leave a black hole. */
function setArt(img, appid) {
  img.hidden = false;
  img.onerror = () => { img.hidden = true; };
  img.onload = () => { if (img.naturalWidth <= 2) img.hidden = true; };
  img.src = "/api/img/" + appid;
}

function saveLocal() {
  try {
    localStorage.setItem("sw.pool", JSON.stringify([...State.pool]));
    localStorage.setItem("sw.cats", JSON.stringify([...State.cats]));
  } catch (e) { /* ignore */ }
}

/* ------------------------------------------------------------ copy rules */

/* Enough copies to go around? Copy counts only mean something once the family
 * token is in - until then every game reports a single owner, so enforcing the
 * rule would black out the whole library. */
function hasCopies(g, party) {
  if (!State.copiesKnown) return true;
  if (State.copyRule === "off") return true;
  if (State.copyRule === "loose") return (g.copies || 1) >= 1;
  return (g.copies || 1) >= (party || State.party);
}

/* Does the game itself seat the party? Solo-only is the reliable signal here;
 * anything higher is derived, so an untagged game is never blocked. */
function seatsParty(g, party) {
  if (State.capacityRule === "off") return true;
  if (!g.tagged || !g.max_players) return true;
  return g.max_players >= (party || State.party);
}

function playable(g, party) { return hasCopies(g, party) && seatsParty(g, party); }

/** No categories chosen means anything goes. */
function inChosenCats(g) {
  if (!State.cats.size) return true;
  return (g.cats || []).some((c) => State.cats.has(c));
}

function eligible(g) { return playable(g) && inChosenCats(g); }

/* ------------------------------------------------------------------ boot */

async function boot() {
  wheel = new Wheel($("wheel"));

  /* Rigged used to be set by right-clicking the pool list, which is gone.
   * Right-click the slice itself instead - closer to "rig this game" anyway. */
  $("wheel").addEventListener("contextmenu", (ev) => {
    ev.preventDefault();
    if (!Mutators.isOn("rigged")) {
      toast("Turn on the Rigged mutator first");
      return;
    }
    const s = sliceAtEvent(ev);
    if (!s || s.virtual) return;
    State.rigged = State.rigged === s.appid ? null : s.appid;
    toast(State.rigged ? "Rigged toward " + s.name : "Rigging cleared");
    rebuildWheel(true);
  });

  wheel.onTick = () => {
    const p = el(".pointer");
    p.classList.remove("tick");
    void p.offsetWidth;
    p.classList.add("tick");
  };

  try {
    const cfg = await api("/api/config");
    State.party = cfg.party_size || 4;
    State.copyRule = cfg.copy_rule || "strict";
    State.capacityRule = cfg.capacity_rule || "on";
    State.tokenExpires = cfg.token_expires || 0;
    State.steamid = cfg.steamid || "";
    $("cfg-steamid").value = cfg.steamid || "";
  } catch (e) {
    toast("Could not read config - is server.py still running?");
  }

  try {
    const saved = JSON.parse(localStorage.getItem("sw.pool") || "[]");
    if (Array.isArray(saved)) saved.forEach((id) => State.pool.add(id));
    const c = JSON.parse(localStorage.getItem("sw.cats") || "[]");
    if (Array.isArray(c)) c.forEach((x) => State.cats.add(x));
  } catch (e) { /* ignore */ }

  $("party-count").textContent = State.party;
  $("lib-copyrule").value = State.copyRule;
  $("lib-caprule").value = State.capacityRule;
  renderMutators();
  wireUI();
  showPicker();
  await loadLibrary(false);
}

async function loadLibrary(refresh) {
  $("hub-sub").textContent = refresh ? "importing…" : "loading…";
  try {
    const data = await api("/api/library" + (refresh ? "?refresh=1" : ""));
    State.games = data.games || [];
    State.members = data.members || [];
    State.sources = data.sources || [];
    State.warnings = data.warnings || [];
    State.tokenExpires = data.token_expires || State.tokenExpires;
    State.byId = new Map(State.games.map((g) => [g.appid, g]));
    State.copiesKnown = State.members.length > 1 ||
      State.games.some((g) => (g.copies || 0) > 1);
    /* A badge every single game carries tells you nothing - only show these
     * when they actually distinguish one game from another. */
    State.playtimeKnown = State.games.some((g) => (g.playtime || 0) > 0);
    State.installedVaries = State.games.some((g) => !g.installed);
    State.allCats = data.categories || [];
    State.tagProgress = data.tag_progress || null;
    /* drop chosen categories that no longer exist */
    const names = new Set(State.allCats.map((c) => c.name));
    [...State.cats].forEach((c) => { if (!names.has(c)) State.cats.delete(c); });

    /* drop pool entries that no longer exist */
    [...State.pool].forEach((id) => { if (!State.byId.has(id)) State.pool.delete(id); });

    if (!State.pool.size && State.games.length) generatePool(true);
  } catch (e) {
    State.warnings = ["Could not load the library: " + e.message];
  }
  renderStatus();
  renderLibrary();
  rebuildWheel(false);
  if (State.view === "picker") renderCategories();

  /* tagging runs for ~40 min on a big library; refresh the picker as it lands */
  if (State.tagProgress && State.tagProgress.running) {
    clearTimeout(loadLibrary._poll);
    loadLibrary._poll = setTimeout(() => loadLibrary(false), 20000);
  }
}

function shuffled(list) {
  const a = list.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = (Math.random() * (i + 1)) | 0;
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Roll 12 random games that fit the current party size onto the wheel. */
function generatePool(quiet) {
  const fits = State.games.filter(eligible);
  if (!fits.length) {
    const anyCat = State.games.filter(playable).length;
    toast(State.cats.size && anyCat
      ? "Nothing in " + [...State.cats].join(" / ") + " fits a party of " + State.party +
        ". Pick more categories, or drop the party size."
      : "No games fit a party of " + State.party +
        ". Try a smaller party, or loosen the copies rule in the Library.", 5200);
    return false;
  }
  const pick = shuffled(fits).slice(0, 12);
  State.pool = new Set(pick.map((g) => g.appid));
  State.rigged = null;
  resetRound(true);
  saveLocal();
  rebuildWheel(true);
  renderLibrary();
  if (!quiet) {
    toast(pick.length < 12
      ? "Only " + pick.length + " games fit a party of " + State.party + " - all of them are on the wheel"
      : "Rolled 12 games for a party of " + State.party);
  }
  return true;
}

/* ------------------------------------------------------ category picker */

function renderCategories() {
  const grid = $("cat-grid");
  grid.innerHTML = "";

  if (!State.allCats.length) {
    grid.innerHTML = '<div class="empty" style="grid-column:1/-1">' +
      (State.tagProgress && State.tagProgress.running
        ? "Tagging the library… categories appear as they land."
        : "No categories yet. Setup → Re-import, then tagging runs automatically.") +
      "</div>";
    updatePickerFoot();
    return;
  }

  /* Categories the party can actually play come first - with a strict copies
   * rule most of the library is out, and a wall of "0 fit" reads as broken. */
  const rows = State.allCats.map((c) => {
    const inCat = State.games.filter((g) => (g.cats || []).includes(c.name));
    return { name: c.name, count: c.count, inCat, fit: inCat.filter(playable).length };
  }).sort((a, b) => b.fit - a.fit || b.count - a.count);

  const frag = document.createDocumentFragment();
  for (const c of rows) {
    const inCat = c.inCat;
    const fit = c.fit;

    /* draw art from the whole category so collages differ between tiles */
    const picks = shuffled(inCat).slice(0, 4);

    const tile = document.createElement("button");
    tile.className = "cat" + (State.cats.has(c.name) ? " on" : "") + (fit ? "" : " thin");
    tile.innerHTML =
      '<div class="cat-art">' +
      picks.map((g) => '<img loading="lazy" src="/api/img/' + g.appid + '" alt="">').join("") +
      "</div>" +
      '<div class="cat-check">&#10003;</div>' +
      '<div class="cat-body">' +
      '<div class="cat-name">' + c.name + "</div>" +
      '<div class="cat-count">' + c.count + " games</div>" +
      '<div class="cat-fit' + (fit ? "" : " none") + '">' +
      (fit ? fit + " fit a party of " + State.party
           : "none fit a party of " + State.party) + "</div>" +
      "</div>";
    tile.onclick = () => {
      if (State.cats.has(c.name)) State.cats.delete(c.name);
      else State.cats.add(c.name);
      tile.classList.toggle("on", State.cats.has(c.name));
      saveLocal();
      updatePickerFoot();
    };
    frag.appendChild(tile);
  }
  grid.appendChild(frag);
  fitCatGrid();
  updatePickerFoot();
}

/* Choose the column count that gets every category on screen at once, as large
 * as it can be. CSS auto-fill can't do this: it packs columns by width alone and
 * happily pushes the last row out of view. */
function fitCatGrid() {
  const grid = $("cat-grid");
  const n = grid.children.length;
  if (!n) return;

  const gap = parseFloat(getComputedStyle(grid).gap) || 14;
  const W = grid.clientWidth;
  const H = grid.clientHeight;
  if (W < 40 || H < 40) return;

  let best = null;
  for (let cols = 1; cols <= n; cols++) {
    const rows = Math.ceil(n / cols);
    const tw = (W - gap * (cols - 1)) / cols;
    const th = (H - gap * (rows - 1)) / rows;
    if (tw < 148 || th < 82) continue;          // below this it stops being readable
    /* biggest tile that stays near a landscape-ish shape */
    const score = tw * th - Math.abs(tw / th - 1.8) * 5200;
    if (!best || score > best.score) best = { cols, tw, th, score };
  }
  /* nothing fits cleanly - fall back to a sane width and let it scroll */
  if (!best) {
    grid.style.gridTemplateColumns = "repeat(auto-fit, minmax(200px, 1fr))";
    grid.style.gridAutoRows = "minmax(112px, 1fr)";
    grid.style.overflowY = "auto";
    grid.classList.add("compact");
    return;
  }
  grid.style.gridTemplateColumns = "repeat(" + best.cols + ", 1fr)";
  grid.style.gridAutoRows = "1fr";
  grid.style.overflowY = "hidden";
  grid.classList.toggle("compact", best.th < 132);
}

function updatePickerFoot() {
  const n = State.cats.size;
  const pool = State.games.filter(eligible).length;
  $("picker-count").textContent = n
    ? n + (n === 1 ? " category" : " categories") + " · " + pool + " games fit a party of " + State.party
    : "Nothing picked — Surprise me uses the whole library";
  $("cat-go").disabled = false;
  $("cat-go").textContent = n ? "To the wheel →" : "Use everything →";
}

/* The four screens: categories -> wheel, or categories -> roster -> bracket.
 * Top-bar controls that only mean something at the wheel travel with it. */
const VIEWS = {
  picker: "view-picker", wheel: "view-wheel",
  roster: "view-roster", bracket: "view-bracket",
};

function setView(name) {
  State.view = name;
  for (const key in VIEWS) $(VIEWS[key]).hidden = key !== name;
  const atWheel = name === "wheel";
  el(".party").hidden = !atWheel;
  $("generate").hidden = !atWheel;
  $("open-mutators").hidden = !atWheel;
  $("back-cats").hidden = name === "picker";
}

/** Picker -> wheel, with the tiles scattering and the wheel dropping in. */
function goToWheel(generate) {
  const picker = $("view-picker");
  const stage = $("view-wheel");
  picker.classList.add("leaving");

  setTimeout(() => {
    picker.classList.remove("leaving");
    setView("wheel");

    if (generate) generatePool(true);
    else rebuildWheel(false);

    stage.classList.add("entering");
    setTimeout(() => stage.classList.remove("entering"), 800);

    const n = State.cats.size;
    toast(n ? [...State.cats].join(" · ") + " — " + wheel.slices.length + " on the wheel"
            : "Whole library — " + wheel.slices.length + " on the wheel");
  }, 430);
}

function showPicker() {
  const picker = $("view-picker");
  setView("picker");
  renderCategories();
  requestAnimationFrame(fitCatGrid);
  picker.classList.add("entering");
  setTimeout(() => picker.classList.remove("entering"), 600);
}

/* --------------------------------------------------------------- status */

function renderStatus() {
  const box = $("status");
  const bits = [];

  if (State.sources.length) {
    bits.push('<span class="ok">&#10003;</span> <b>' + State.sources.join("</b> &middot; <b>") + "</b>");
  }
  /* Listing six raw SteamID64s is just noise - only name them once resolved. */
  if (State.members.length > 1) {
    const named = State.members.filter((m) => m.name && m.name !== m.steamid);
    if (named.length) bits.push("Family: " + named.map((m) => m.name).join(", "));
  }
  if (State.tokenExpires) {
    const left = State.tokenExpires * 1000 - Date.now();
    bits.push(left > 0
      ? "Token valid " + Math.floor(left / 3600000) + "h " + Math.floor((left % 3600000) / 60000) + "m"
      : '<span class="bad">Family token expired - paste a fresh one in Setup</span>');
  }
  const tp = State.tagProgress;
  if (tp && tp.running) {
    bits.push('<span class="ok">Tagging games ' + tp.done + "/" + tp.total + "…</span>");
  }
  if (State.games.length && !State.copiesKnown) {
    bits.push("Copy counting is off until a Steam Family token is saved in Setup.");
  }
  State.warnings.forEach((w) => bits.push('<span class="bad">' + w + "</span>"));

  box.innerHTML = bits.join(" &nbsp;|&nbsp; ");
  box.hidden = !bits.length;
}

/* ------------------------------------------------------------- mutators */

function renderMutators() {
  const box = $("mutators");
  $("mut-count").textContent = Mutators.live().length;
  $("mut-intro").textContent =
    "Toggle any combination - they change how slices are weighted and what landing means.";
  box.innerHTML = "";
  Mutators.all().forEach((m) => {
    const on = Mutators.isOn(m.id);
    const row = document.createElement("label");
    row.className = "mut" + (on ? " on" : "");
    row.innerHTML =
      '<input type="checkbox"' + (on ? " checked" : "") + ">" +
      '<span><span class="mut-name">' + m.name + "</span><br>" +
      '<span class="mut-desc">' + m.desc + "</span></span>";
    el("input", row).addEventListener("change", (ev) => {
      Mutators.toggle(m.id, ev.target.checked);
      row.classList.toggle("on", ev.target.checked);
      if (m.id === "timebomb") ev.target.checked ? armBomb() : disarmBomb();
      $("mut-count").textContent = Mutators.live().length;
      rebuildWheel(true);
    });
    box.appendChild(row);
  });
}

/* ------------------------------------------------------------------ pool */

function poolGames() {
  return [...State.pool]
    .map((id) => State.byId.get(id))
    .filter(Boolean)
    .filter((g) => !State.removed.has(g.appid));
}

function renderPool() {
  $("pool-count").textContent = State.pool.size;
}

/* ------------------------------------------------------------- the wheel */

function mutatorCtx() {
  return {
    party: State.party,
    rigged: State.rigged,
    survived: State.survived,
    allGames: State.games,
    poolIds: State.pool,
    playable,
  };
}

function rebuildWheel(animate) {
  const ctx = mutatorCtx();
  const base = poolGames().map((g) => ({ ...g, weight: Mutators.weightFor(g, ctx) }));
  const extra = Mutators.extraSlices(ctx).map((g) => ({ ...g, weight: Mutators.weightFor(g, ctx) }));
  const all = base.concat(extra);

  wheel.blackout = false;
  wheel.setSlices(all, animate);
  renderPool();
  updateHub();
  renderWheelBar();
}

function updateHub() {
  const n = wheel.slices.length;
  $("spin").disabled = n < 1 || wheel.spinning;
  if (bombTimer) return;
  $("hub-sub").textContent = !n ? "all played" : n === 1 ? "1 left" : n + " left";
}

function renderWheelBar() {
  const total = State.pool.size;
  const gone = State.removed.size;
  const left = total - gone;
  $("wheel-fill").style.width = total ? (gone / total) * 100 + "%" : "0%";
  $("wheel-text").textContent = !total
    ? "Nothing on the wheel"
    : gone === 0 ? total + " on the wheel"
      : left === 0 ? "All played - hit Generate for a fresh set"
        : gone + " picked · " + left + " left";
}

/* ------------------------------------------------------------------ round */

function resetRound(quiet) {
  State.removed.clear();
  State.survived = {};
  State.pendingRemoval = null;
  State.doubleUsed = false;
  if (!quiet) rebuildWheel(true);
}

/* ------------------------------------------------------------------ spins */

async function doSpin() {
  disarmBomb();
  if (wheel.spinning || wheel.slices.length < 1) return;
  if (Mutators.isOn("blackout")) wheel.blackout = true;

  $("spin").disabled = true;
  const idx = wheel.pickIndex();
  const landed = await wheel.spin(idx);
  wheel.blackout = false;
  wheel.render();

  await resolveSpin(landed);
  updateHub();
  armBombIfEnabled();
}

async function resolveSpin(slice) {
  const verdict = Mutators.resolve(slice, mutatorCtx());

  /* Virtual slices are not real games - nothing to take off the wheel. */
  if (verdict.verdict === "golden") {
    Audio2.land();
    showWinner(null, "Golden Ticket", verdict.note, []);
    pushHistory("Golden Ticket", "win");
    return;
  }
  if (verdict.verdict === "wildcard") {
    Audio2.land();
    const i = wheel.slices.indexOf(slice);
    const n = wheel.slices.length;
    const a = wheel.slices[(i - 1 + n) % n], b = wheel.slices[(i + 1) % n];
    showWinner(null, "Wildcard", verdict.note, [a, b].filter((x) => x && !x.virtual));
    pushHistory("Wildcard", "win");
    return;
  }

  /* Everything the wheel passed over gets a little heavier for Ante Up. */
  poolGames().forEach((o) => {
    if (o.appid !== slice.appid) State.survived[o.appid] = (State.survived[o.appid] || 0) + 1;
  });

  Audio2.land();
  const g = State.byId.get(slice.appid) || slice;
  /* Held until the card is dismissed, so you see what you won before it goes. */
  State.pendingRemoval = slice.virtual ? null : g.appid;
  showWinner(g, slice.virtual === "cursed" ? "Cursed pick" : "The wheel has spoken", "", []);
  pushHistory(g.name, "win");
}

/** Take the game just shown off the wheel, with the slices closing the gap. */
function consumeWinner() {
  const id = State.pendingRemoval;
  State.pendingRemoval = null;
  if (id === null || id === undefined) return;

  const g = State.byId.get(id);
  State.removed.add(id);

  /* Double Helping: past halfway, each pick drags a second game down with it. */
  let extra = null;
  if (Mutators.isOn("sudden") && State.removed.size >= Math.floor(State.pool.size / 2)) {
    const rest = poolGames();
    if (rest.length > 1) {
      extra = rest[(Math.random() * rest.length) | 0];
      State.removed.add(extra.appid);
      pushHistory(extra.name + " (double helping)", "out");
    }
  }

  rebuildWheel(true);
  const left = poolGames().length;
  const who = (g ? g.name : "That game") + (extra ? " and " + extra.name : "");
  toast(left ? who + " off the wheel — " + left + " left"
             : who + " off the wheel — that is the lot");
}

/* ---------------------------------------------------------------- winner */

function showWinner(game, kicker, note, options) {
  const ov = $("winner-overlay");
  $("winner-kicker").textContent = kicker;

  if (game) {
    setArt($("winner-art"), game.appid);
    $("winner-name").textContent = game.name;
    const owners = ownerNames(game);
    const fam = game.family_playtime || game.playtime || 0;
    $("winner-meta").textContent =
      (game.copies || 1) + " " + ((game.copies || 1) === 1 ? "copy" : "copies") +
      " in the family · " + (fam ? fmtMins(fam) + " played across the family" : "nobody has played it") +
      (game.max_players ? " · up to " + game.max_players + "p" : "") +
      (game.installed ? " · installed" : "");
    const rows = playerRows(game);
    /* Rows arrive sorted by hours, so the first one with time on the clock is
     * the family's expert - worth a star when the game lands. */
    const champ = rows.find((r) => r.mins > 0);
    if (rows.some((r) => r.named)) {
      $("winner-owners").innerHTML = rows.map((r) =>
        '<span class="owner-pill' + (r.mins ? " played" : "") +
        (r === champ ? " top" : "") + '">' +
        (r === champ ? '<i class="star" title="Most hours in the family">&#9733;</i>' : "") +
        r.name +
        (r.hidden ? ' <i>hidden</i>' : ' <b>' + fmtMins(r.mins) + "</b>") +
        "</span>").join(" ");
    } else {
      /* No Web API key: every owner reads the same, so collapse to a count. */
      const anon = owners.length;
      $("winner-owners").innerHTML = anon
        ? '<span class="owner-pill">' + anon +
          (anon === 1 ? " family member owns this" : " family members own this") + "</span>"
        : "";
    }
    $("winner-launch").hidden = false;
    $("winner-launch").onclick = () => { window.location.href = "steam://run/" + game.appid; };
  } else {
    $("winner-art").hidden = true;
    $("winner-name").textContent = note || kicker;
    $("winner-meta").textContent = options && options.length
      ? "Choose between: " + options.map((s) => s.name).join("  vs  ")
      : "";
    $("winner-owners").innerHTML = "";
    $("winner-launch").hidden = true;
  }

  /* Both ways out of this card retire the game, then the wheel closes the gap. */
  const again = $("winner-again");
  const canDouble = Mutators.isOn("double") && !State.doubleUsed && game;
  again.textContent = canDouble ? "Double or Nothing" : "Spin again";
  again.onclick = () => {
    if (canDouble) State.doubleUsed = true;
    ov.hidden = true;
    consumeWinner();
    /* let the slices finish reflowing before the next spin */
    setTimeout(() => { if (wheel.slices.length) doSpin(); }, 620);
  };

  ov.hidden = false;
}

function pushHistory(text, kind) {
  const li = document.createElement("li");
  li.className = kind;
  const t = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  li.innerHTML = '<span class="nm"><b>' + t + "</b> " + text + "</span>";
  const list = $("history");
  el(".empty", list) && list.replaceChildren();
  list.prepend(li);
  while (list.children.length > 40) list.lastChild.remove();
}

/* --------------------------------------------------------------- library */

function libFiltered() {
  const q = $("lib-search").value.trim().toLowerCase();
  const instOnly = $("lib-installed").checked;
  const playOnly = $("lib-playable").checked;
  const sort = $("lib-sort").value;

  let out = State.games.filter((g) => {
    if (q && !g.name.toLowerCase().includes(q)) return false;
    if (instOnly && !g.installed) return false;
    if (playOnly && !playable(g)) return false;
    return true;
  });

  const cmp = {
    name: (a, b) => a.name.localeCompare(b.name),
    copies: (a, b) => (b.copies || 1) - (a.copies || 1) || a.name.localeCompare(b.name),
    playtime: (a, b) => (b.playtime || 0) - (a.playtime || 0),
    unplayed: (a, b) => (a.playtime || 0) - (b.playtime || 0),
    recent: (a, b) => (b.acquired || 0) - (a.acquired || 0),
  }[sort];
  out.sort(cmp);
  return out;
}

function renderLibrary() {
  const grid = $("lib-grid");
  const list = libFiltered();
  const shown = list.slice(0, 400);

  grid.innerHTML = "";
  const frag = document.createDocumentFragment();

  shown.forEach((g) => {
    const ok = playable(g);
    const card = document.createElement("div");
    card.className = "card" + (State.pool.has(g.appid) ? " sel" : "") + (ok ? "" : " locked");
    card.innerHTML =
      '<img loading="lazy" src="/api/img/' + g.appid + '" alt="">' +
      '<div class="badges">' +
      (State.copiesKnown
        ? '<span class="badge ' + (ok ? "good" : "bad") + '">' + (g.copies || 1) +
          ((g.copies || 1) === 1 ? " copy" : " copies") + "</span>"
        : "") +
      (g.max_players
        ? '<span class="badge cap' + (g.cap_basis === "manual" ? " manual" : "") + '">' +
          (g.max_players === 1 ? "solo" : "≤" + g.max_players + "p") + "</span>"
        : "") +
      /* Only worth saying for multiplayer games - "solo" is already on the cap
       * badge, and "versus" on everything competitive would be noise. */
      (g.format === "unfit" || g.format === "mixed"
        ? '<span class="badge fmt ' + g.format + '">' +
          (g.format === "unfit" ? "no winner" : "house rule") + "</span>"
        : "") +
      (g.installed && State.installedVaries ? '<span class="badge inst">installed</span>' : "") +
      (!g.playtime && State.playtimeKnown ? '<span class="badge">unplayed</span>' : "") +
      "</div>" +
      '<div class="pick">&#10003;</div>' +
      '<div class="cname">' + g.name + "</div>";
    const im = el("img", card);
    im.onerror = () => im.classList.add("noart");
    im.onload = () => { if (im.naturalWidth <= 2) im.classList.add("noart"); };
    card.oncontextmenu = (ev) => { ev.preventDefault(); openCapPop(ev, g); };
    card.title = ok ? "" : "Only " + (g.copies || 1) + " copies in the family for a party of " + State.party;
    card.onclick = () => {
      if (State.pool.has(g.appid)) State.pool.delete(g.appid);
      else State.pool.add(g.appid);
      card.classList.toggle("sel", State.pool.has(g.appid));
      saveLocal();
      resetRound(true);
      rebuildWheel(true);
      updateLibStat(list);
    };
    frag.appendChild(card);
  });

  grid.appendChild(frag);
  if (list.length > shown.length) {
    const more = document.createElement("div");
    more.className = "empty";
    more.style.gridColumn = "1/-1";
    more.textContent = "Showing 400 of " + list.length + " - narrow the search to see the rest.";
    grid.appendChild(more);
  }
  updateLibStat(list);
  $("pool-count").textContent = State.pool.size;
}

function updateLibStat(list) {
  const total = State.games.length;
  const head = (list ? list.length + " shown · " : "") + State.pool.size + " on the wheel";
  $("lib-stat").textContent = State.copiesKnown
    ? head + " · " + State.games.filter(playable).length + " of " + total +
      " fit a party of " + State.party
    : head + " · " + total + " games (copy counts need the family token)";
}

/* ---------------------------------------------------- format override */

const FORMAT_BLURB = {
  versus: "Someone wins by playing it as intended.",
  mixed: "No versus mode — a bracket needs an agreed rule.",
  unfit: "Co-op or story: playing it produces no winner.",
  solo: "Single-player only.",
};

/* The versus score is a heuristic and will be wrong somewhere in a large library,
 * so it shows its working and can always be overruled by hand. */
function renderFormatRow(g) {
  const box = $("fmt-row");
  if (!g.tagged) { box.hidden = true; return; }
  box.hidden = false;

  const f = g.format || "mixed";
  $("fmt-verdict").className = "fmt-verdict " + f;
  $("fmt-verdict").textContent =
    { versus: "Versus", mixed: "House rule", unfit: "No winner", solo: "Solo" }[f] || f;
  $("fmt-why").textContent = (FORMAT_BLURB[f] || "") +
    (g.format_manual ? " Set by hand here."
      : g.versus_score === undefined || g.versus_score === null ? ""
      : " Score " + g.versus_score + ".") +
    (f === "mixed" && g.win_cond ? " Suggested: " + g.win_cond + "." : "");

  els(".fmt-set").forEach((b) => {
    b.classList.toggle("on", b.dataset.fmt === f);
    b.onclick = () => setFormat(g, b.dataset.fmt === f ? "" : b.dataset.fmt);
  });
}

async function setFormat(g, fmt) {
  $("cap-pop").hidden = true;
  try {
    await api("/api/format", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ appid: g.appid, format: fmt }),
    });
    /* Clearing hands the game back to the classifier, whose verdict we no
     * longer hold locally - a reload is the honest way to show it again. */
    if (fmt) {
      g.format = fmt;
      g.format_manual = true;
      if (fmt === "mixed" && !g.win_cond) g.win_cond = "Best run in a fixed time";
      toast(g.name + " → " + fmt);
    } else {
      g.format_manual = false;
      toast("Back to the automatic verdict for " + g.name + " — re-import to refresh it");
    }
    renderLibrary();
  } catch (e) {
    toast("Could not save: " + e.message);
  }
}

/* ------------------------------------------------- max-players override */

/* Steam publishes no max-player figure, so the number is derived. This is the
 * escape hatch for the games where the guess is wrong. */
function openCapPop(ev, g) {
  const pop = $("cap-pop");
  const basis = {
    solo: "Steam lists this as single-player only.",
    tag: "Taken from a community tag.",
    guess: "Derived from its multiplayer modes — Steam publishes no real number.",
    manual: "Set by hand here.",
  }[g.cap_basis] || "Not tagged yet.";

  $("cap-pop-title").textContent = g.name;

  /* who has actually played it, and for how long */
  const rows = playerRows(g).filter((r) => r.named);
  const list = $("cap-pop-players");
  if (rows.length) {
    const champ = rows.find((r) => r.mins > 0);
    list.innerHTML = rows.map((r) =>
      '<div class="pp-row' + (r === champ ? " top" : "") + '">' +
      '<span class="pp-name">' + (r === champ ? "&#9733; " : "") + r.name + "</span>" +
      '<span class="pp-time' + (r.mins ? "" : " zero") + '">' +
      (r.hidden ? "hidden" : fmtMins(r.mins)) + "</span></div>").join("");
    list.hidden = false;
  } else {
    list.hidden = true;
  }

  $("cap-pop-sub").textContent = (g.max_players ? "Max " + g.max_players +
    (g.max_players === 1 ? " player. " : " players. ") : "No cap. ") + basis;
  $("cap-pop-input").value = g.max_players || "";
  renderFormatRow(g);
  pop.hidden = false;

  const w = 252, pad = 12;
  const h = pop.offsetHeight || 240;
  pop.style.left = Math.max(pad, Math.min(window.innerWidth - w - pad, ev.clientX - w / 2)) + "px";
  pop.style.top = Math.max(pad, Math.min(window.innerHeight - h - pad, ev.clientY + 10)) + "px";
  $("cap-pop-input").focus();

  const send = async (n) => {
    pop.hidden = true;
    try {
      await api("/api/override", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ appid: g.appid, max_players: n }),
      });
      g.max_players = n || 0;
      g.cap_basis = n ? "manual" : "";
      toast(n ? g.name + " set to " + n + " players" : "Override cleared for " + g.name);
      renderLibrary();
      rebuildWheel(true);
    } catch (e) {
      toast("Could not save: " + e.message);
    }
  };

  $("cap-pop-save").onclick = () => send(parseInt($("cap-pop-input").value, 10) || 0);
  $("cap-pop-clear").onclick = () => send(0);
  $("cap-pop-input").onkeydown = (k) => {
    if (k.key === "Enter") send(parseInt($("cap-pop-input").value, 10) || 0);
    if (k.key === "Escape") pop.hidden = true;
  };
}

/* -------------------------------------------------------------- time bomb */

function armBombIfEnabled() {
  if (Mutators.isOn("timebomb") && wheel.slices.length >= 2) armBomb();
}

function armBomb() {
  disarmBomb();
  if (!Mutators.isOn("timebomb")) return;
  bombLeft = 15;
  bombTimer = setInterval(() => {
    if (!$("winner-overlay").hidden || wheel.spinning) return;
    bombLeft--;
    $("hub-sub").textContent = "auto-spin in " + bombLeft;
    if (bombLeft <= 0) { disarmBomb(); doSpin(); }
    else if (bombLeft <= 5) Audio2.blip(660, 0.06, "square", 0.03);
  }, 1000);
}

function disarmBomb() {
  if (bombTimer) clearInterval(bombTimer);
  bombTimer = null;
  updateHub();
}

/* ------------------------------------------------------------------- wiring */

function wireUI() {
  $("spin").onclick = doSpin;

  $("party-minus").onclick = () => setParty(State.party - 1);
  $("party-plus").onclick = () => setParty(State.party + 1);

  $("generate").onclick = () => generatePool(false);

  $("cat-go").onclick = () => goToWheel(true);
  $("cat-any").onclick = () => {
    State.cats.clear();
    saveLocal();
    renderCategories();
    goToWheel(true);
  };
  $("cat-clear").onclick = () => { State.cats.clear(); saveLocal(); renderCategories(); };
  $("back-cats").onclick = showPicker;
  wireTournament();

  document.addEventListener("mousedown", (ev) => {
    const pop = $("cap-pop");
    if (!pop.hidden && !pop.contains(ev.target)) pop.hidden = true;
  });
  $("open-library").onclick = () => { $("library-modal").hidden = false; renderLibrary(); };
  $("open-mutators").onclick = () => { $("mutators-modal").hidden = false; renderMutators(); };
  $("open-setup").onclick = () => { $("setup-modal").hidden = false; showTokenStatus(); };
  els("[data-close]").forEach((b) => { b.onclick = () => { b.closest(".modal").hidden = true; }; });
  els(".modal").forEach((m) => {
    m.onclick = (ev) => { if (ev.target === m) m.hidden = true; };
  });

  $("lib-search").oninput = () => renderLibrary();
  $("lib-installed").onchange = () => renderLibrary();
  $("lib-playable").onchange = () => renderLibrary();
  $("lib-sort").onchange = () => renderLibrary();
  const saveRule = (patch) => api("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(patch),
  }).catch(() => {});

  $("lib-copyrule").onchange = (ev) => {
    State.copyRule = ev.target.value;
    saveRule({ copy_rule: State.copyRule });
    renderLibrary();
    rebuildWheel(true);
  };
  $("lib-caprule").onchange = (ev) => {
    State.capacityRule = ev.target.value;
    saveRule({ capacity_rule: State.capacityRule });
    renderLibrary();
    rebuildWheel(true);
  };

  $("lib-all").onclick = () => {
    libFiltered().slice(0, 60).forEach((g) => State.pool.add(g.appid));
    saveLocal(); resetRound(true); rebuildWheel(true); renderLibrary();
    toast("Added up to 60 games from the current filter");
  };
  $("lib-none").onclick = () => {
    libFiltered().forEach((g) => State.pool.delete(g.appid));
    saveLocal(); resetRound(true); rebuildWheel(true); renderLibrary();
  };
  $("lib-top").onclick = () => {
    const pick = libFiltered().slice();
    for (let i = pick.length - 1; i > 0; i--) {
      const j = (Math.random() * (i + 1)) | 0;
      [pick[i], pick[j]] = [pick[j], pick[i]];
    }
    State.pool.clear();
    pick.slice(0, 12).forEach((g) => State.pool.add(g.appid));
    saveLocal(); resetRound(true); rebuildWheel(true); renderLibrary();
    toast("Rolled a fresh 12");
  };

  $("mut-clear").onclick = () => { Mutators.clear(); renderMutators(); disarmBomb(); rebuildWheel(true); };
  $("hist-clear").onclick = () => { $("history").innerHTML = '<li class="empty">No spins yet.</li>'; };

  $("winner-close").onclick = () => {
    $("winner-overlay").hidden = true;
    consumeWinner();
    updateHub();
    armBombIfEnabled();
  };

  $("cfg-retag").onclick = async () => {
    const r = await api("/api/tags/refresh", { method: "POST" }).catch(() => null);
    toast(!r ? "Could not start tagging"
      : r.already ? "Already tagging"
      : r.queued ? "Tagging " + r.queued + " games — the status bar tracks it"
      : "Everything is already tagged");
    setTimeout(() => loadLibrary(false), 1500);
  };

  /* Closing the browser tab leaves the server running in its console window,
   * which is a confusing way to end the night. */
  $("cfg-quit").onclick = async () => {
    await api("/api/quit").catch(() => {});   /* GET route, see server.py */
    document.body.innerHTML =
      '<div class="bye">Wheelhouse has stopped.<br><small>You can close this tab.</small></div>';
  };

  $("cfg-save").onclick = saveSetup;
  $("cfg-refresh").onclick = async () => {
    toast("Re-importing from Steam…");
    await loadLibrary(true);
    toast("Library refreshed");
    showTokenStatus();
  };

  document.addEventListener("keydown", (ev) => {
    if (/input|textarea|select/i.test(ev.target.tagName)) return;
    if (ev.key === "Escape") els(".modal, .overlay").forEach((m) => { m.hidden = true; });
    if (ev.key === "l" || ev.key === "L") $("open-library").click();
    if (State.view !== "wheel") return;
    if (ev.code === "Space") { ev.preventDefault(); doSpin(); }
    if (ev.key === "g" || ev.key === "G") generatePool(false);
    if (ev.key === "m" || ev.key === "M") {
      Audio2.muted = !Audio2.muted;
      toast(Audio2.muted ? "Sound off" : "Sound on");
    }
    if (ev.key === "r" || ev.key === "R") { resetRound(true); rebuildWheel(true); toast("Round reset"); }
  });

  window.addEventListener("resize", () => {
    wheel.render();
    if (State.view === "picker") fitCatGrid();
  });
}

/* Changing the party size no longer reshuffles the wheel behind your back -
 * it re-filters the library and waits for you to hit Generate. */
function setParty(n) {
  State.party = Math.max(1, Math.min(12, n));
  $("party-count").textContent = State.party;
  api("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ party_size: State.party }),
  }).catch(() => {});
  renderLibrary();
  const fits = State.games.filter(eligible).length;
  $("generate").title = fits + " games fit a party of " + State.party;
  if (State.view === "picker") renderCategories();
}

function showTokenStatus() {
  const box = $("token-status");
  if (!State.tokenExpires) {
    box.className = "warn";
    box.textContent = "No family token saved yet - copy counts will fall back to 1 per game.";
    return;
  }
  const left = State.tokenExpires * 1000 - Date.now();
  if (left > 0) {
    box.className = "warn ok";
    box.textContent = "Token valid for another " + Math.floor(left / 3600000) + "h " +
      Math.floor((left % 3600000) / 60000) + "m.";
  } else {
    box.className = "warn bad";
    box.textContent = "Token expired. Paste a fresh one and hit Save.";
  }
}

async function saveSetup() {
  const patch = { steamid: $("cfg-steamid").value.trim() };
  const key = $("cfg-apikey").value.trim();
  const tok = $("cfg-token").value.trim().replace(/^"|"$/g, "");
  if (key) patch.api_key = key;
  if (tok) patch.access_token = tok;

  $("cfg-save").disabled = true;
  try {
    await api("/api/config", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    $("cfg-apikey").value = "";
    $("cfg-token").value = "";
    toast("Saved - importing from Steam…");
    await loadLibrary(true);
    const cfg = await api("/api/config");
    State.tokenExpires = cfg.token_expires || 0;
    showTokenStatus();
    toast(State.warnings.length ? "Imported with warnings - see the status bar" : "Library imported");
  } catch (e) {
    toast("Save failed: " + e.message);
  } finally {
    $("cfg-save").disabled = false;
  }
}

boot();
