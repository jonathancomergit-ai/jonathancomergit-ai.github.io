/* Tournament mode - single elimination on a manually typed roster.
 *
 * The flow reuses the category picker: pick categories, then a roster screen
 * where the players are typed in by hand and a slider sets how many of them
 * play at once. That slider is also the game filter - a 2-player match can use
 * anything, an 8-player match needs a game that actually seats eight - so the
 * eligible-game count moves with it.
 *
 * Every match is dealt a random game from what survives that filter. Win your
 * match, move to the next column. Loaded before app.js: these are function
 * declarations, so app.js can call them from wireUI().
 */

const SEAT_LABELS = {
  2: "Head to head. The classic bracket.",
  3: "Three at a time, one survivor per match.",
  4: "Four-player heats - one winner goes through.",
  5: "Five-player heats. Fewer games will fit.",
  6: "Six at once. Only party games get this big.",
  7: "Seven-player heats. Very few games qualify.",
  8: "Eight at once. Expect a short list.",
};

/* ------------------------------------------------------------ game pool */

/* A bracket needs a game that produces a winner. "versus" games do that on
 * their own; "mixed" ones can, but only once the room agrees a house rule, so
 * they are opt-in. An untagged game is an unknown quantity, which is exactly
 * what "mixed" means - it rides along only when house rules are allowed. */
function bracketFormat(g) {
  if (!g.tagged || !g.format) return "mixed";
  return g.format;
}

function fitsFormat(g) {
  const f = bracketFormat(g);
  return f === "versus" || (State.houseRules && f === "mixed");
}

/** Games in the chosen categories that seat one match AND can be won. */
function tourneyPool(seats) {
  return State.games.filter(
    (g) => inChosenCats(g) && hasCopies(g, seats) && seatsParty(g, seats) && fitsFormat(g)
  );
}

/** The same pool ignoring the format rule, to say what the rule is costing. */
function tourneyPoolAnyFormat(seats) {
  return State.games.filter(
    (g) => inChosenCats(g) && hasCopies(g, seats) && seatsParty(g, seats)
  );
}

/* --------------------------------------------------------- bracket build */

/* A slot is either a typed name or a promise of whoever wins an earlier match.
 * Building the whole tree upfront is what lets every match be dealt its game
 * before a single round is played.
 *
 * The bracket is sized to a power of the match size - 2, 4, 8, 16 for
 * head-to-head - which is what makes every round after the first completely
 * full. All the awkwardness of an odd roster is paid for in round one, as byes,
 * exactly like a printed bracket. Positions are kept on every match and bye so
 * the two halves can be laid out facing each other.
 */
function buildBracket(names, seats, pool) {
  const players = shuffled(names);
  let size = seats, depth = 1;
  while (size < players.length) { size *= seats; depth++; }

  const T = { v: 2, seats, names: names.slice(), rounds: [], at: Date.now() };
  const bag = shuffled(pool);
  let bi = 0;
  /* Cycle the bag rather than run dry: a 16-player bracket off three eligible
   * games should still be dealt three games, not blanks. */
  const deal = () => (bag.length ? bag[bi++ % bag.length].appid : null);

  /* Round one. Everyone gets a slot of their own first - depth is minimal, so
   * there are always fewer groups than players - and whoever is left over is
   * spread across evenly spaced groups. Dealing them in order instead would
   * stack every contested match at the top and leave the bottom half nothing
   * but byes. */
  let groups = [];
  for (let i = 0; i < size / seats; i++) groups.push([]);
  const wide = groups.length;
  const extra = players.length - wide;
  players.forEach((p, i) => {
    const slot = { kind: "name", name: p };
    if (i < wide) { groups[i].push(slot); return; }
    let pos = Math.floor(((i - wide) * wide) / extra) % wide;
    /* Uneven splits can land twice on one group; walk to the next with room. */
    for (let n = 0; groups[pos].length >= seats && n < wide; n++) pos = (pos + 1) % wide;
    groups[pos].push(slot);
  });

  for (let r = 0; r < depth; r++) {
    const matches = [], byes = [];
    groups.forEach((slots, pos) => {
      if (slots.length === 1) { byes.push({ slot: slots[0], pos }); return; }
      const appid = deal();
      const src = appid ? State.byId.get(appid) : null;
      matches.push({
        r, m: matches.length, pos, slots, winner: null, appid,
        /* Captured at build time so the card still explains itself after a
         * reload, when the library may not be loaded yet. */
        win: (src && bracketFormat(src) === "mixed" && src.win_cond) || "",
      });
    });
    T.rounds.push({ matches, byes });

    /* Rebuild the field in bracket order - a bye holds its place - then chunk
     * it into the next round's groups. */
    const next = [];
    let mi = 0, byi = 0;
    groups.forEach((slots) => {
      next.push(slots.length === 1 ? byes[byi++].slot : { kind: "from", r, m: mi++ });
    });
    groups = [];
    for (let i = 0; i < next.length; i += seats) groups.push(next.slice(i, i + seats));
  }
  return T;
}

/** How many cards a round holds, matches and byes together. */
function roundWidth(T, r) {
  return T.rounds[r].matches.length + T.rounds[r].byes.length;
}

/* Which half of the bracket a card sits in. The field halves cleanly every
 * round, so a position in the top half always descends from the top half. */
function sideAt(T, r, pos) {
  return pos < Math.ceil(roundWidth(T, r) / 2) ? "left" : "right";
}

/** Who is in this slot, or null while the feeding match is undecided. */
function slotName(T, s) {
  if (s.kind === "name") return s.name;
  const m = T.rounds[s.r].matches[s.m];
  return m.winner === null ? null : slotName(T, m.slots[m.winner]);
}

function matchReady(T, m) {
  return m.slots.every((s) => slotName(T, s) !== null);
}

function roundLabel(T, i) {
  const left = T.rounds.length - i;
  if (left === 1) return "Final";
  if (left === 2) return "Semi-finals";
  if (left === 3) return "Quarter-finals";
  return "Round " + (i + 1);
}

function championOf(T) {
  const last = T.rounds[T.rounds.length - 1];
  if (!last) return null;
  const m = last.matches[0];
  return m && m.winner !== null ? slotName(T, m.slots[m.winner]) : null;
}

function tourneyProgress(T) {
  let done = 0, total = 0;
  T.rounds.forEach((rd) => rd.matches.forEach((m) => {
    total++;
    if (m.winner !== null) done++;
  }));
  return { done, total };
}

/* ------------------------------------------------------------ persistence */

function saveTourney() {
  try {
    localStorage.setItem("sw.tourney", State.tourney ? JSON.stringify(State.tourney) : "");
  } catch (e) { /* private window */ }
}

function loadTourney() {
  try {
    const n = +localStorage.getItem("sw.seats");
    if (n >= 2 && n <= 8) State.seats = n;
    State.houseRules = localStorage.getItem("sw.house") === "1";
    const raw = localStorage.getItem("sw.tourney");
    if (!raw) return;
    const T = JSON.parse(raw);
    if (T && T.v === 2 && Array.isArray(T.rounds) && T.rounds.length) State.tourney = T;
  } catch (e) { /* ignore */ }
}

/* ------------------------------------------------------------- roster UI */

function rosterRow(name) {
  const li = document.createElement("li");
  li.className = "roster-row";
  li.innerHTML =
    '<span class="seed"></span>' +
    '<input class="roster-name" maxlength="24" placeholder="Player name" autocomplete="off">' +
    '<button class="x" title="Remove">&times;</button>';
  const input = el(".roster-name", li);
  input.value = name || "";
  input.oninput = updateRosterFoot;
  input.onkeydown = (ev) => {
    if (ev.key === "Enter") {
      ev.preventDefault();
      const rows = els(".roster-row");
      const next = rows[rows.indexOf(li) + 1];
      if (next) el(".roster-name", next).focus();
      else addRosterRow(true);
    }
  };
  el(".x", li).onclick = () => {
    li.remove();
    renumberRoster();
    updateRosterFoot();
  };
  return li;
}

function addRosterRow(focus) {
  const li = rosterRow("");
  $("roster-list").appendChild(li);
  renumberRoster();
  updateRosterFoot();
  if (focus) el(".roster-name", li).focus();
  return li;
}

function renumberRoster() {
  els(".roster-row").forEach((li, i) => { el(".seed", li).textContent = i + 1; });
}

/** Typed names, in order, blanks dropped. */
function rosterNames() {
  return els(".roster-name").map((i) => i.value.trim()).filter(Boolean);
}

function renderRoster(names) {
  const list = $("roster-list");
  list.replaceChildren();
  const seed = names && names.length ? names : ["", "", "", ""];
  seed.forEach((n) => list.appendChild(rosterRow(n)));
  renumberRoster();

  $("house-rules").checked = !!State.houseRules;
  const slider = $("seat-slider");
  slider.value = State.seats;
  $("seat-ticks").innerHTML = [2, 3, 4, 5, 6, 7, 8]
    .map((n) => "<span>" + n + "</span>").join("");
  updateSeats();
  updateRosterFoot();
}

/** Slider moved: retitle it and re-count what is still playable. */
function updateSeats() {
  const seats = State.seats;
  $("seat-out").textContent = seats;
  $("seat-label").textContent = SEAT_LABELS[seats] || "";

  const pool = tourneyPool(seats);
  const seated = tourneyPoolAnyFormat(seats);
  const where = State.cats.size ? [...State.cats].join(" · ") : "the whole library";
  const dropped = seated.length - pool.length;
  $("seat-fit").innerHTML = pool.length
    ? "<b>" + pool.length + "</b> game" + (pool.length === 1 ? "" : "s") +
      " in " + where + " seat " + seats + " and can be won" +
      (dropped ? '<span class="drop">' + dropped +
        " co-op or story game" + (dropped === 1 ? "" : "s") + " set aside</span>" : "")
    : '<span class="none">Nothing in ' + where + " seats " + seats +
      " players and produces a winner — widen the categories, drop the slider, " +
      "or allow house rules.</span>";

  const mixed = seated.filter((g) => bracketFormat(g) === "mixed").length;
  $("house-note").textContent = State.houseRules
    ? "Games with no versus mode are in, each with a house rule on its card."
    : mixed + " more could play with an agreed rule (fastest time, best score).";

  /* Overflow is clipped, so an over-long list simply fills the panel. */
  $("seat-sample").innerHTML = shuffled(pool).slice(0, 14)
    .map((g) => "<li>" + g.name + "</li>").join("");

  const slider = $("seat-slider");
  slider.style.setProperty("--fill", ((seats - 2) / 6 * 100).toFixed(1) + "%");
}

function updateRosterFoot() {
  const n = rosterNames().length;
  const pool = tourneyPool(State.seats).length;
  $("roster-count").textContent = n < 2
    ? "Add at least two players"
    : n + " players · " + pool + " games to draw from";
  $("roster-note").textContent = n ? n + " named" : "";
  $("roster-go").disabled = n < 2 || pool === 0;
}

/* ------------------------------------------------------------ bracket UI */

function renderBracket() {
  const T = State.tourney;
  const wrap = $("bracket");
  wrap.replaceChildren();
  if (!T) return;

  const last = T.rounds.length - 1;

  /* Left halves run inward, the final and the trophy sit in the middle, then
   * the right halves run back out - a printed bracket, both sides facing in. */
  for (let r = 0; r < last; r++) wrap.appendChild(sideColumn(T, r, "left"));
  wrap.appendChild(centreColumn(T));
  for (let r = last - 1; r >= 0; r--) wrap.appendChild(sideColumn(T, r, "right"));

  const champ = championOf(T);
  const p = tourneyProgress(T);
  $("bracket-sub").textContent =
    T.names.length + " players · " + T.seats + " per match · " +
    (State.cats.size ? [...State.cats].join(" · ") : "whole library");
  $("bracket-count").textContent = champ
    ? champ + " takes it — " + p.total + " matches played"
    : p.done + " of " + p.total + " matches played";
  $("bracket-title").textContent = champ ? champ + " wins the tournament" : "The bracket";
}

/** One round's cards for one half of the bracket, top to bottom. */
function sideColumn(T, r, side) {
  const rd = T.rounds[r];
  const col = document.createElement("div");
  col.className = "b-col " + side;
  /* Columns nearest the middle animate in last, so the bracket fills inward. */
  col.style.setProperty("--col", r);
  /* The label is a fixed header and the cards flex below it, so every round
   * title lines up across both halves however many cards sit under it. */
  col.innerHTML = '<div class="b-round">' + roundLabel(T, r) + "</div>" +
                  '<div class="b-cards"></div>';
  const body = el(".b-cards", col);

  const cards = [];
  rd.matches.forEach((m) => {
    if (sideAt(T, r, m.pos) === side) cards.push([m.pos, matchCard(T, m, r)]);
  });
  rd.byes.forEach((b) => {
    if (sideAt(T, r, b.pos) !== side) return;
    const name = slotName(T, b.slot);
    const el2 = document.createElement("div");
    el2.className = "b-bye" + (name ? "" : " tbd") + (r > 0 ? " fed" : "");
    el2.innerHTML = "<b>" + (name || "TBD") + "</b><span>bye — straight through</span>";
    cards.push([b.pos, el2]);
  });

  cards.sort((x, y) => x[0] - y[0]).forEach(([, node]) => body.appendChild(node));
  if (!cards.length) col.classList.add("empty-col");
  return col;
}

/** The final plus the trophy, dead centre. */
function centreColumn(T) {
  const r = T.rounds.length - 1;
  const champ = championOf(T);
  const col = document.createElement("div");
  col.className = "b-col b-centre";
  col.style.setProperty("--col", r);

  const cup = document.createElement("div");
  cup.className = "b-champ" + (champ ? " won" : " tbd");
  cup.innerHTML =
    '<div class="trophy">' + (champ ? "&#127942;" : "&#9734;") + "</div>" +
    "<b>" + (champ || "Champion") + "</b>";
  col.appendChild(cup);

  const label = document.createElement("div");
  label.className = "b-round";
  label.textContent = "Final";
  col.appendChild(label);

  T.rounds[r].matches.forEach((m) => col.appendChild(matchCard(T, m, r)));
  return col;
}

function matchCard(T, m, roundIdx) {
  const ready = matchReady(T, m);
  const done = m.winner !== null;
  const g = m.appid ? State.byId.get(m.appid) : null;

  const card = document.createElement("div");
  card.className = "b-match" + (done ? " done" : ready ? " live" : " locked");
  if (roundIdx > 0) card.classList.add("fed");

  /* The capsule is the whole head of the card - at this size it is the fastest
   * way to recognise the game across the room. */
  const head = document.createElement("div");
  head.className = "b-game";
  if (g) {
    const img = document.createElement("img");
    img.alt = "";
    setArt(img, g.appid);
    head.appendChild(img);
    const nm = document.createElement("span");
    nm.className = "b-gname";
    nm.textContent = g.name;
    head.appendChild(nm);
    if (!done) {
      const die = document.createElement("button");
      die.className = "b-die";
      die.title = "Draw a different game";
      die.innerHTML = "&#127922;";
      die.onclick = (ev) => { ev.stopPropagation(); rerollMatch(m); };
      head.appendChild(die);
    }
  } else {
    head.classList.add("noart");
    head.innerHTML = '<span class="b-nogame">No game fits — reroll or widen the categories</span>';
  }
  card.appendChild(head);

  /* House-rule games have no built-in winner, so the card states the rule. */
  if (m.win) {
    const rule = document.createElement("div");
    rule.className = "b-rule";
    rule.innerHTML = "&#9873; " + m.win;
    card.appendChild(rule);
  }

  m.slots.forEach((s, i) => {
    const name = slotName(T, s);
    const b = document.createElement("button");
    b.className = "b-player" +
      (done && m.winner === i ? " win" : "") +
      (done && m.winner !== i ? " lose" : "");
    b.disabled = !ready;
    b.innerHTML = '<span class="b-nm">' + (name || "TBD") + "</span>" +
      '<span class="b-pick">' + (done && m.winner === i ? "&#10003;" : "won") + "</span>";
    b.onclick = () => setWinner(m, i);
    card.appendChild(b);
  });

  return card;
}

/* --------------------------------------------------------------- actions */

function setWinner(m, i) {
  const T = State.tourney;
  if (!T || !matchReady(T, m)) return;
  const already = m.winner === i;
  const who = slotName(T, m.slots[i]);
  m.winner = already ? null : i;        // click again to undo a misclick
  if (already) {
    /* An undone result leaves later rounds pointing at someone who is no
     * longer through, so everything downstream of it goes too. */
    clearDownstream(T, m.r);
  } else {
    const g = State.byId.get(m.appid);
    pushHistory(who + " wins " + (g ? g.name : "their match"), "win");
  }
  saveTourney();
  renderBracket();
  updateTourneyButton();

  const champ = championOf(T);
  if (champ && !already) {
    toast("🏆 " + champ + " wins the tournament");
    $("bracket").classList.add("crowned");
    setTimeout(() => $("bracket").classList.remove("crowned"), 2400);
  }
}

/** Wipe results in every round after r - they were built on the old winner. */
function clearDownstream(T, r) {
  for (let i = r + 1; i < T.rounds.length; i++) {
    T.rounds[i].matches.forEach((m) => { m.winner = null; });
  }
}

function rerollMatch(m) {
  const T = State.tourney;
  const used = new Set();
  T.rounds.forEach((rd) => rd.matches.forEach((x) => x.appid && used.add(x.appid)));
  const pool = tourneyPool(T.seats);
  const fresh = pool.filter((g) => !used.has(g.appid));
  const from = fresh.length ? fresh : pool.filter((g) => g.appid !== m.appid);
  if (!from.length) { toast("No other game fits this match size"); return; }
  const pick = shuffled(from)[0];
  m.appid = pick.appid;
  m.win = (bracketFormat(pick) === "mixed" && pick.win_cond) || "";
  saveTourney();
  renderBracket();
}

function rerollAllGames() {
  const T = State.tourney;
  if (!T) return;
  const bag = shuffled(tourneyPool(T.seats));
  if (!bag.length) { toast("No games fit that match size"); return; }
  let i = 0;
  T.rounds.forEach((rd) => rd.matches.forEach((m) => {
    const pick = bag[i++ % bag.length];
    m.appid = pick.appid;
    m.win = (bracketFormat(pick) === "mixed" && pick.win_cond) || "";
  }));
  saveTourney();
  renderBracket();
  toast("Fresh games dealt to every match");
}

/* ----------------------------------------------------------- navigation */

function showRoster() {
  setView("roster");
  renderRoster(State.tourney ? State.tourney.names : null);
  const sec = $("view-roster");
  sec.classList.add("entering");
  setTimeout(() => sec.classList.remove("entering"), 600);
}

/** Roster -> bracket, with the columns dealing themselves in. */
function goToBracket() {
  const names = rosterNames();
  const pool = tourneyPool(State.seats);
  if (names.length < 2) { toast("Two players minimum"); return; }
  if (!pool.length) { toast("No games seat " + State.seats + " players"); return; }

  const dupes = names.length !== new Set(names.map((n) => n.toLowerCase())).size;
  if (dupes) toast("Two players share a name — the bracket still works, it just reads oddly");

  State.tourney = buildBracket(names, State.seats, pool);
  saveTourney();

  const sec = $("view-roster");
  sec.classList.add("leaving");
  setTimeout(() => {
    sec.classList.remove("leaving");
    setView("bracket");
    renderBracket();
    const b = $("view-bracket");
    b.classList.add("entering");
    setTimeout(() => b.classList.remove("entering"), 900);
    pushHistory(names.length + "-player tournament started", "win");
    toast(names.length + " players · " + State.tourney.rounds.length + " rounds");
  }, 380);
}

function resumeTourney() {
  if (!State.tourney) { showRoster(); return; }
  setView("bracket");
  renderBracket();
}

/** Reflects whether there is a tournament worth going back to. */
function updateTourneyButton() {
  const b = $("cat-tourney");
  if (!b) return;
  const live = State.tourney && !championOf(State.tourney);
  b.textContent = live ? "Resume tournament →" : "Tournament →";
  b.classList.toggle("live", !!live);
}

function wireTournament() {
  loadTourney();

  $("cat-tourney").onclick = () => (State.tourney && !championOf(State.tourney)
    ? resumeTourney() : showRoster());

  $("house-rules").onchange = (ev) => {
    State.houseRules = ev.target.checked;
    try { localStorage.setItem("sw.house", State.houseRules ? "1" : "0"); } catch (e) { /* ignore */ }
    updateSeats();
    updateRosterFoot();
  };
  $("roster-add").onclick = () => addRosterRow(true);
  $("roster-back").onclick = showPicker;
  $("roster-go").onclick = goToBracket;
  $("seat-slider").oninput = (ev) => {
    State.seats = +ev.target.value;
    try { localStorage.setItem("sw.seats", String(State.seats)); } catch (e) { /* ignore */ }
    updateSeats();
    updateRosterFoot();
  };

  $("bracket-back").onclick = showRoster;
  $("bracket-reroll").onclick = rerollAllGames;
  $("bracket-new").onclick = () => {
    State.tourney = null;
    saveTourney();
    updateTourneyButton();
    showRoster();
  };

  updateTourneyButton();
}
