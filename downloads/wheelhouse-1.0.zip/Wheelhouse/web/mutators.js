/* Mutators - toggleable rules that bend how the wheel is built and resolved.
 *
 * Each mutator may implement any of:
 *   weight(game, ctx) -> multiplier applied to that game's slice size
 *   slices(ctx)       -> extra "virtual" slices injected into the wheel
 *   onLand(slice,ctx) -> {verdict, note} to override what landing means
 */

const MUTATORS = [
  {
    id: "underplayed",
    name: "Underplayed Bias",
    desc: "The less the family has played it, the fatter its slice. Actually clears the backlog.",
    weight(g) { return 1 + 6 / (1 + (g.playtime || 0) / 60); },
  },
  {
    id: "fresh",
    name: "Cold Storage",
    desc: "Anything played in the last 30 days is shrunk hard. No repeats of last week's game.",
    weight(g) {
      if (!g.last_played) return 1;
      const days = (Date.now() / 1000 - g.last_played) / 86400;
      return days < 30 ? 0.15 : 1;
    },
  },
  {
    id: "wellstocked",
    name: "Well Stocked",
    desc: "Games with copies to spare get weighted up, so nobody sits out.",
    weight(g, ctx) {
      const spare = (g.copies || 1) - ctx.party;
      return spare >= 2 ? 2.2 : spare >= 0 ? 1.4 : 1;
    },
  },
  {
    id: "rigged",
    name: "Rigged",
    desc: "Secretly triple the odds of one game. Right-click its slice on the wheel to mark it. Tell no one.",
    weight(g, ctx) { return ctx.rigged === g.appid ? 3 : 1; },
  },
  {
    id: "cursed",
    name: "Cursed Slice",
    desc: "Injects one game NOBODY has ever played. Landing on it is contractually binding.",
    slices(ctx) {
      const virgins = ctx.allGames.filter(
        (g) => !g.playtime && ctx.playable(g) && !ctx.poolIds.has(g.appid)
      );
      if (!virgins.length) return [];
      const pick = virgins[(Math.random() * virgins.length) | 0];
      return [{ ...pick, virtual: "cursed", label: "CURSED: " + pick.name, weight: 1.5 }];
    },
  },
  {
    id: "golden",
    name: "Golden Ticket",
    desc: "A thin gold slice. Land it and the spinner gets a free dictator pick - any game, no argument.",
    slices() {
      return [{
        appid: -1, name: "GOLDEN TICKET", label: "GOLDEN TICKET",
        virtual: "golden", weight: 0.55, copies: 99, owners: [], playtime: 0,
      }];
    },
    onLand(s) {
      return s.virtual === "golden"
        ? { verdict: "golden", note: "Golden Ticket! The spinner picks anything they want." }
        : null;
    },
  },
  {
    id: "wildcard",
    name: "Wildcard",
    desc: "Adds a WILDCARD slice. Land it and the party votes between the two nearest slices.",
    slices() {
      return [{
        appid: -2, name: "WILDCARD", label: "WILDCARD",
        virtual: "wildcard", weight: 0.8, copies: 99, owners: [], playtime: 0,
      }];
    },
    onLand(s) {
      return s.virtual === "wildcard"
        ? { verdict: "wildcard", note: "Wildcard! Vote between the two slices either side." }
        : null;
    },
  },
  {
    id: "double",
    name: "Double or Nothing",
    desc: "One re-roll is offered after the wheel lands. Take it and the second result is binding.",
  },
  {
    id: "blackout",
    name: "Blackout",
    desc: "Slice names are hidden while it spins. Nobody finds out what is playing until it stops.",
  },
  {
    id: "sudden",
    name: "Double Helping",
    desc: "Once half the wheel is gone, every pick takes a second game down with it.",
  },
  {
    id: "ante",
    name: "Ante Up",
    desc: "Every game the wheel passes over gets a fatter slice, so the ones it keeps skipping get likelier.",
    weight(g, ctx) { return 1 + 0.45 * (ctx.survived[g.appid] || 0); },
  },
  {
    id: "timebomb",
    name: "Time Bomb",
    desc: "Fifteen seconds of dithering and the wheel spins itself. No more group indecision.",
  },
];

const Mutators = {
  active: new Set(),
  byId: Object.fromEntries(MUTATORS.map((m) => [m.id, m])),

  isOn(id) { return this.active.has(id); },

  toggle(id, on) {
    if (on === undefined) on = !this.active.has(id);
    if (on) this.active.add(id); else this.active.delete(id);
    this.save();
    return on;
  },

  clear() { this.active.clear(); this.save(); },

  all() { return MUTATORS; },

  /** Every mutator currently switched on. */
  live() {
    return MUTATORS.filter((m) => this.active.has(m.id));
  },

  /** Combined weight multiplier for one game. */
  weightFor(game, ctx) {
    let w = game.weight || 1;
    for (const m of this.live()) {
      if (m.weight) w *= m.weight(game, ctx);
    }
    return Math.max(0.05, w);
  },

  /** Virtual slices contributed by active mutators. */
  extraSlices(ctx) {
    const out = [];
    for (const m of this.live()) {
      if (m.slices) out.push(...m.slices(ctx));
    }
    return out;
  },

  /** Let a mutator reinterpret the landed slice. */
  resolve(slice, ctx) {
    for (const m of this.live()) {
      if (m.onLand) {
        const r = m.onLand(slice, ctx);
        if (r) return r;
      }
    }
    return { verdict: "normal", note: "" };
  },

  save() {
    try {
      localStorage.setItem("sw.mutators", JSON.stringify([...this.active]));
    } catch (e) { /* private window, no big deal */ }
  },

  load() {
    try {
      const raw = JSON.parse(localStorage.getItem("sw.mutators") || "[]");
      if (Array.isArray(raw)) raw.forEach((id) => this.byId[id] && this.active.add(id));
    } catch (e) { /* ignore */ }
  },
};

Mutators.load();
