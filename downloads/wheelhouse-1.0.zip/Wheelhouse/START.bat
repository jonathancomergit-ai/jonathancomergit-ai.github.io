@echo off
title Wheelhouse
cd /d "%~dp0"

rem py.exe is the reliable launcher. Bare "python" on Windows 11 is often an App
rem Execution Alias that silently opens the Microsoft Store instead of running
rem anything, so it is only tried if it answers --version for real.
where py >nul 2>nul
if %errorlevel%==0 goto run_py

python --version >nul 2>nul
if %errorlevel%==0 goto run_python

echo.
echo   Python 3 is not installed, or Windows is pointing "python" at the Store.
echo.
echo   Install it from https://www.python.org/downloads/  and tick
echo   "Add python.exe to PATH" on the first screen of the installer.
echo.
pause
exit /b 1

:run_py
py -3 server.py
goto done

:run_python
python server.py

:done
echo.
echo Wheelhouse has stopped.
pause
