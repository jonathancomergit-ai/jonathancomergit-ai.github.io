# Wheelhouse

A spin-the-wheel night for you and your friends, built on your real Steam library.
Double-click **START.bat**. It opens in your browser. That is the whole install.

In a hurry? **QUICKSTART.txt** is the one-page version. This file is the reference.

---

## The one thing worth setting up: the family token

Out of the box the app reads the games installed on this PC and you can spin
immediately. But the good feature — **knowing how many copies of a game your
Steam Family owns, so the wheel only offers games your whole party can actually
play** — needs one token.

1. Log into Steam **in your browser**.
2. Open <https://store.steampowered.com/pointssummary/ajaxgetasyncconfig>
3. You will see something like `{"webapi_token":"eyJ0eXAi...."}`. Copy the long
   value between the quotes.
4. In the app: **Setup** → paste into *Steam Family access token* → **Save & import library**.

That token **expires about every 24 hours.** The status bar across the top tells
you how long it has left, and says so plainly when it dies. Re-paste a fresh one
and hit Save — it takes ten seconds and your wheel setup is untouched.

### Optional: Web API key

<https://steamcommunity.com/dev/apikey> (needs a phone-verified Steam account).
Paste it into Setup and family members show up as **real names** instead of
SteamID numbers. Everything works without it.

Both are stored in `config.json` next to this file and are only ever sent to Steam.

---

## Picking what to play

Unpicked tiles sit dark and desaturated; **picking one brings its art up to full
brightness** with an ice-blue ring, so the board reads at a glance from across
the room.

The app opens on the **category picker** — a tile per genre, each showing a
collage from your own library, how many games it holds, and how many of those
your current party can actually play. Pick as many as you like (or **Surprise
me** for the whole library), and the tiles scatter into the wheel.

Categories the party can play are sorted first; ones with nothing playable at
the current size are dimmed rather than hidden, so you can see what a smaller
party would unlock. **← Categories** in the top bar goes back.

---

## Player counts

Steam publishes **no max-player number** in any API. What it does publish, per
game, is the set of modes: Single-player, Co-op, PvP, MMO, Shared/Split Screen.
So the cap is derived:

| Situation | Cap | How solid |
|---|---|---|
| Steam lists Single-player only | **1** | Definitive — this is the fix for "5 copies of a solo city-builder" |
| A community tag states it ("4 Player Local") | that number | Good |
| Co-op modes present | 4 | A guess |
| Multiplayer / PvP | 8 | A guess |
| MMO | 12 | A guess |

The guesses will sometimes be wrong — plenty of co-op games seat 6 or 8.
**Right-click any game in the Library** to set its real maximum by hand; that
override wins over the derived value and survives re-imports forever. Cards show
the cap as a badge (`solo`, `≤4p`), tinted blue when you set it yourself.

If the guessing gets in your way, the Library's **Player cap** dropdown turns the
whole rule off.

---

## Who has played what

With a Web API key saved, the app pulls each family member's own playtime and
shows it per game:

* **The winner card** lists everyone attached to the game, most hours first, with
  a gold ★ on whoever in the family has the most hours in the game that just
  landed —
  `AceOfClubs 238h · pixelmoth 25h · tinribs 10h`. Everyone is named by their
  Steam persona — the app never says "you", since the reader is not always the
  account it is set up under.
* **Right-click any Library card** for the full breakdown, alongside the
  max-players control.

Steam only serves another account's playtime when that person has set **game
details to Public**, so expect gaps. The app is explicit about which kind of gap
it is: `never` means they own it and have not played it; **`hidden`** means Steam
will not say. Nobody is ever reported as having zero hours when the truth is
unknown. The status bar names anyone whose playtime is not public.

Visibility is read fresh on every import, so when someone flips their profile to
public it takes one **Setup -> Re-import from Steam** to pick them up — no code
change, no restart.

This also sharpens two mutators — Underplayed Bias and Cold Storage now weigh the
family's combined hours rather than a single figure.

---

## Party size and copies

Set **Party** in the top bar to how many of you are playing, then hit
**Generate** — it rolls 12 random games that your party actually has enough
copies of, straight onto the wheel. Changing the party size on its own does not
disturb the wheel; nothing moves until you press Generate.

If fewer than 12 games qualify, it puts all of them on and tells you. Each game
shows how many copies your family owns, and the Library greys out anything you
are short on.

The **Copies rule** dropdown in the Library controls how strict that is:

| Rule | Meaning |
|---|---|
| **Strict** | Need one copy per player. The honest default. |
| **Loose** | Anyone in the family owns it — sort the rest out yourselves. |
| **Off** | Ignore copies entirely. |

A caveat worth knowing: Steam Family Sharing only lets **one** person borrow from
a given library at a time, so "3 owners" genuinely does mean about 3 simultaneous
players. Strict is the rule that matches reality. Use Loose for single-player
games you are all watching, or co-op games with a free friend pass.

Until a family token is saved, every game reports one copy, so copy filtering
switches itself off rather than blanking your whole library.

---

## How a night runs

Spin. The wheel lands, the reveal card shows the game with its copies, who has
played it and for how long, and a Launch on Steam button.

Then — whether you hit **Spin again** or just **Close** — that game comes *off*
the wheel, the slices close the gap, and the field is one smaller. Spin again and
you cannot draw it twice.

So the wheel narrows as the night goes on. The bar under it tracks how many are
picked and how many are left. When it empties, **Generate** rolls a fresh set;
`R` puts everything back without regenerating.

## Does it produce a winner?

Genre and seat count answer *what is it* and *does everyone fit*. A bracket needs
a third answer that neither gives: **does playing this produce a winner, in one
sitting?** Baldur's Gate 3 seats four and is tagged Co-op, so it sails through
every other filter and then asks a bracket to crown someone.

So every game carries a **format**, scored from data already on disk:

| Format | Meaning |
|---|---|
| `versus` | Someone wins by playing it as intended |
| `mixed` | No versus mode — needs an agreed house rule |
| `unfit` | Co-op or story: playing it produces no winner |
| `solo` | Single-player |

The Library screen shows how many of yours fall into each.

The strongest signal is Steam's own **PvP** category — Valve-supplied, not
crowd-guessed — weighted up when a game lists several PvP modes. Co-op with *no*
PvP anywhere is the giveaway and scores hard against. Community tags then nudge
either way: *Competitive, Fighting, Party Game* up; *Story Rich, Choices Matter,
Walking Simulator* down; and *MMORPG, Grand Strategy, Open World Survival Craft*
down again, because a bracket match has to finish before the evening does.

Two rules keep it honest. A game Valve marks PvP can be held at `mixed` by
session-length doubts but never sunk to `unfit` — ShellShock Live should not be
demoted by a stray *Massively Multiplayer* tag. And a game with **no** PvP mode
can never be `versus`, however party-flavoured its tags: without a versus mode
you always need a house rule, which is exactly what `mixed` means.

It is a heuristic and it will be wrong somewhere in a library of any size, so **right-click
any game** to see its verdict, the score behind it, and three buttons to overrule
it by hand. Overrides live in `config.json` and beat the classifier.

None of this touches the wheel. A co-op story night is a perfectly good wheel
night; this only decides what a *bracket* may draw.

---

## Tournament mode

Same start as a normal night — pick your categories — then hit **Tournament**
instead of *To the wheel*.

**The roster is typed by hand.** Nobody needs a Steam account to compete, so
partners, kids and whoever wandered in all go on the same bracket. Enter moves to
the next row, `+ Add player` adds one, `x` removes one.

**Only games that can be won are dealt.** By default a bracket draws from
`versus` games only; the roster screen says how many co-op or story games it set
aside and offers one toggle — *allow games that need a house rule* — to add the
`mixed` ones. Those arrive with their rule printed on the match card ("Last one
standing", "First to solve it", "Fastest lap"), so the room agrees the terms
before anyone starts. It is off by default: a bracket that silently includes
games needing a house rule is how you get an argument at 11pm.

**The slider sets players per match, and that is also the game filter.** Two per
match is the classic head-to-head bracket and almost everything qualifies; slide
it to eight and only genuine party games survive. The count under it moves as you
drag — `31 games in Party · Fighting seat 2 players` — with a sample list so you
can see what you would actually be drawing from. It greys out the Build button
if nothing fits.

**Build the bracket** and it draws like a printed one — two halves facing each
other, feeding a final and a trophy in the middle. Every match, the final
included, is dealt a random game from that pool up front, shown as full capsule
art so you can read the board across the room. Click whoever won and they slide
into the next column; the loser greys out. Click the same name again to undo a
misclick, which also clears every result that was built on it.

Odd numbers are fine. The bracket is sized to a power of the match size, so all
the awkwardness of eleven players is paid for in round one as **byes**, spread
across both halves — every round after the first is completely full. 🎲 on any undecided match deals it a different game, **Reroll games**
redeals the lot, and the bracket survives a browser refresh — close the laptop
mid-tournament and it is still there.

---

## Mutators

Behind the **Mutators** button in the top bar; the chip shows how many are
active. All of them are available at once. They apply to the wheel — a
tournament draws its games directly, so mutators sit it out.

| Mutator | Effect |
|---|---|
| Underplayed Bias | The less the family has played it, the fatter its slice. Clears the backlog. |
| Cold Storage | Anything played in the last 30 days is shrunk hard. |
| Well Stocked | Games with copies to spare get weighted up so nobody sits out. |
| Rigged | Secretly triples one game's odds. **Right-click its slice on the wheel.** |
| Cursed Slice | Injects a game *nobody* has ever played. Landing on it is binding. |
| Golden Ticket | Thin gold slice — spinner gets a free dictator pick. Not a real game, so nothing leaves the wheel. |
| Wildcard | Land it and the party votes between the two neighbouring slices. |
| Double or Nothing | One re-roll offered after landing; the second result is binding. |
| Blackout | Slice names hidden while it spins. |
| Double Helping | Past halfway, every pick drags a second game off the wheel with it. |
| Ante Up | Every game the wheel passes over gets a fatter slice, so the perpetually-skipped get likelier. |
| Time Bomb | 15 seconds of dithering and the wheel spins itself. |

---

## Keyboard

| Key | Action |
|---|---|
| `Space` | Spin |
| `G` | Generate a fresh 12 for the current party |
| `R` | Put every picked game back on the wheel |
| `M` | Mute / unmute |
| `L` | Library |
| `Esc` | Close whatever is open |

`Space`, `G`, `R` and `M` are wheel-only, so typing a player name into the
tournament roster never sets the wheel spinning.

---

## How it works

The look is "space glass": near-black and deep blue-grey, panels rendered as
translucent panes with `backdrop-filter` over a CSS starfield, and a single ice
accent for anything actionable. Everything derives from tokens at the top of
`style.css` — recolour `--accent` and the whole UI follows. Blur is dropped for
`prefers-reduced-motion`, and the library grid opts out of it entirely because a
few hundred blurred cards is not worth the frame time.

- `web/tournament.js` — bracket building, the roster screen and match results.
- `server.py` — local-only web server on 127.0.0.1. Serves the UI, proxies Steam,
  and caches capsule art to `cache/img/` so game night survives a CDN hiccup.
- `steam.py` — the data layer. Three sources, tried in order: **Steam Family**
  (the only one that knows about copies), **Web API** owned-games, and a
  **local disk scan** of your `.acf` manifests that needs no credentials at all
  and works offline. Whatever it can reach, it uses; the status bar says which.
- `tags.py` — genre and player-mode tagging. Steam's store API gives the
  authoritative player modes; SteamSpy gives the community tags ("City Builder",
  "Automation", "Roguelike") that Steam's own coarse genres miss. Both are rate
  limited, so a full pass over a large library takes ~40 minutes; it runs in the
  background, writes `cache/tags.json` every 10 games, and the picker fills in
  live as results land. It never re-fetches a game it already knows.
- `web/` — the UI. `wheel.js` does canvas rendering and spin physics,
  `mutators.js` holds the rule definitions, `app.js` wires it together.

The wheel's games and chosen mutators persist in the browser between sessions. The library itself is cached in `cache/library.json`, so the app opens
instantly and still works if Steam is unreachable.

### Self-test

With the app running, open <http://127.0.0.1:8731/_test.html> to run the wheel
and mutator test suite (slice geometry, landing accuracy over 36 spins, weight
ratios, virtual slices, mutator weighting). It should report 16/16.

---

## Troubleshooting

**"Steam rejected the credentials"** — the family token expired. Get a fresh one
(step 2 above).

**Family members show as long numbers** — add a Web API key in Setup.

**A game is missing** — the family library only lists games Steam considers
shareable; some titles are publisher-excluded from Family Sharing. Those are
still importable via your own Web API key.

**A game is in the wrong category** — categories come from SteamSpy community
tags. Nothing to fix in the app; pick more categories to widen the net.

**Categories are missing or say "0 games"** — tagging has not reached those games
yet. The status bar shows progress while it runs.

**Port already in use** — the server picks another port automatically and prints
the real URL in its window.

---

Wheelhouse is an unofficial, non-commercial hobby project. It is **not affiliated
with, authorised or endorsed by Valve Corporation**. Steam and the Steam logo are
trademarks of Valve Corporation. Game artwork belongs to the respective
publishers; it is fetched from Steam at runtime, cached only on your own machine,
and is not distributed with this download.

The Steam Family token this app uses comes from an endpoint Valve does not
document, so it may stop working without warning. Nothing is sent anywhere except
to Steam's own servers.
