"""Steam data layer: Family library, Web API, and offline local-disk scan."""
import base64
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "cache")
API = "https://api.steampowered.com"
UA = {"User-Agent": "SteamWheel/1.0"}

# Runtimes and tools that sit in steamapps but are not games.
NON_GAME_APPIDS = {
    228980,   # Steamworks Common Redistributables
    250820,   # SteamVR
    1070560,  # Steam Linux Runtime 1.0
    1391110,  # Steam Linux Runtime 2.0 (soldier)
    1493710,  # Proton Experimental
    1628350,  # Steam Linux Runtime 3.0 (sniper)
    1826330,  # Proton hotfixes
    2180100,  # Proton 8
    2230260,  # Proton 9
    2348590,  # Proton next
    1887720,  # Proton 7
    1580130,  # Proton 6
    1420170,  # Proton 5
}

NON_GAME_RE = re.compile(
    r"(redistributable|steam linux runtime|^proton\b|steamvr|"
    r"^steam controller|dedicated server|soundtrack$|^blender$)",
    re.I,
)


def is_game(appid, name):
    if int(appid) in NON_GAME_APPIDS:
        return False
    return not NON_GAME_RE.search(name or "")


STEAM_DIRS = [
    r"C:\Program Files (x86)\Steam",
    r"C:\Program Files\Steam",
    r"C:\Steam",
    os.path.expanduser(r"~\scoop\apps\steam\current"),
]


# ---------------------------------------------------------------- VDF parsing

def parse_vdf(text):
    """Minimal Valve KeyValues parser. Enough for .acf / loginusers / libraryfolders."""
    root = {}
    stack = [root]
    key_pending = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("//"):
            continue
        if line == "{":
            node = {}
            if key_pending is not None:
                stack[-1][key_pending] = node
                key_pending = None
            stack.append(node)
            continue
        if line == "}":
            if len(stack) > 1:
                stack.pop()
            continue
        pair = re.findall(r'"((?:[^"\\]|\\.)*)"', line)
        if len(pair) >= 2:
            stack[-1][pair[0]] = pair[1].replace("\\\\", "\\")
        elif len(pair) == 1:
            key_pending = pair[0]
    return root


def find_steam_dir():
    for d in STEAM_DIRS:
        if os.path.isdir(os.path.join(d, "steamapps")):
            return d
    return None


def _last_login():
    """(SteamID64, account record) for the most recently logged-in local user."""
    d = find_steam_dir()
    if not d:
        return None, {}
    path = os.path.join(d, "config", "loginusers.vdf")
    if not os.path.isfile(path):
        return None, {}
    try:
        with open(path, encoding="utf-8", errors="replace") as fh:
            data = parse_vdf(fh.read()).get("users", {})
    except OSError:
        return None, {}
    best, best_info, best_ts = None, {}, -1
    for sid, info in data.items():
        if not isinstance(info, dict):
            continue
        ts = int(info.get("Timestamp") or 0)
        if info.get("MostRecent") == "1":
            ts += 1 << 40
        if ts > best_ts:
            best, best_info, best_ts = sid, info, ts
    return best, best_info


def local_steamid():
    """Best-guess SteamID64 of the most recently logged-in local user."""
    return _last_login()[0]


def local_persona(steamid=None):
    """Display name of the local account, straight off disk - no API key needed.

    Everyone in the room reads the same screen, so the app names people instead
    of saying "you". This is the only name available before a Web API key is set.
    """
    sid, info = _last_login()
    if steamid and sid and str(steamid) != str(sid):
        return ""          # configured account is not the one signed in here
    return (info.get("PersonaName") or info.get("AccountName") or "").strip()


def library_paths():
    d = find_steam_dir()
    if not d:
        return []
    paths = [os.path.join(d, "steamapps")]
    vdf = os.path.join(d, "steamapps", "libraryfolders.vdf")
    if os.path.isfile(vdf):
        try:
            with open(vdf, encoding="utf-8", errors="replace") as fh:
                folders = parse_vdf(fh.read()).get("libraryfolders", {})
            for entry in folders.values():
                if isinstance(entry, dict) and entry.get("path"):
                    p = os.path.join(entry["path"], "steamapps")
                    if os.path.isdir(p) and p not in paths:
                        paths.append(p)
        except OSError:
            pass
    return paths


def scan_installed():
    """Read .acf manifests off disk. No auth, works offline. Installed games only."""
    out = {}
    for lib in library_paths():
        try:
            names = os.listdir(lib)
        except OSError:
            continue
        for fn in names:
            if not (fn.startswith("appmanifest_") and fn.endswith(".acf")):
                continue
            try:
                with open(os.path.join(lib, fn), encoding="utf-8", errors="replace") as fh:
                    st = parse_vdf(fh.read()).get("AppState", {})
            except OSError:
                continue
            appid = st.get("appid")
            if not appid or not appid.isdigit():
                continue
            if not is_game(appid, st.get("name")):
                continue
            out[int(appid)] = {
                "appid": int(appid),
                "name": st.get("name") or ("App " + appid),
                "size_bytes": int(st.get("SizeOnDisk") or 0),
                "last_played": int(st.get("LastPlayed") or 0),
                "installed": True,
            }
    return out


# ------------------------------------------------------------------ HTTP JSON

class SteamError(Exception):
    pass


def _get(path, params, timeout=25):
    url = API + path + "?" + urllib.parse.urlencode(params, doseq=True)
    req = urllib.request.Request(url, headers=UA)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise SteamError(
                "Steam rejected the credentials for " + path + " (HTTP " + str(exc.code) +
                "). The access token has most likely expired - grab a fresh one."
            ) from exc
        raise SteamError("Steam returned HTTP " + str(exc.code) + " for " + path) from exc
    except urllib.error.URLError as exc:
        raise SteamError("Could not reach Steam: " + str(exc.reason)) from exc
    except json.JSONDecodeError as exc:
        raise SteamError("Steam sent a non-JSON reply for " + path) from exc


def token_expiry(token):
    """Read the exp claim out of a Steam webapi JWT without verifying it."""
    try:
        payload = token.split(".")[1]
        payload += "=" * (-len(payload) % 4)
        return int(json.loads(base64.urlsafe_b64decode(payload)).get("exp", 0))
    except Exception:
        return 0


# ------------------------------------------------------------- Steam Family

def family_group(token, steamid):
    """Returns (family_groupid, members, family_name).

    Two calls on purpose: GetFamilyGroupForUser resolves the id but carries no
    member list, so the roster has to come from GetFamilyGroup.
    """
    data = _get("/IFamilyGroupsService/GetFamilyGroupForUser/v1/",
                {"access_token": token, "steamid": steamid}).get("response", {})
    gid = data.get("family_groupid")
    if not gid or data.get("is_not_member_of_any_group"):
        raise SteamError(
            "That Steam account is not in a Steam Family, or the token belongs "
            "to a different account than the SteamID set up here."
        )

    members, name = [], ""
    try:
        grp = _get("/IFamilyGroupsService/GetFamilyGroup/v1/",
                   {"access_token": token, "family_groupid": gid}).get("response", {})
        members = grp.get("members", []) or []
        name = grp.get("name") or ""
    except SteamError:
        pass  # copies still work without the roster; names just stay unknown
    return gid, members, name


def family_library(token, gid, steamid):
    """Every game in the family library, tagged with WHO owns it."""
    data = _get("/IFamilyGroupsService/GetSharedLibraryApps/v1/", {
        "access_token": token,
        "family_groupid": gid,
        "steamid": steamid,
        "include_own": "true",
        "include_excluded": "true",
        "include_free": "false",
        "include_non_games": "false",
        "language": "english",
    }).get("response", {})

    games = []
    for app in data.get("apps", []):
        if not is_game(app["appid"], app.get("name")):
            continue
        owners = [str(o) for o in (app.get("owner_steamids") or [])]
        games.append({
            "appid": int(app["appid"]),
            "name": app.get("name") or ("App " + str(app["appid"])),
            "owners": owners,
            "copies": len(owners),
            # rt_playtime is family playtime in minutes (Apex reads ~990h here).
            "playtime": int(app.get("rt_playtime") or 0),
            "last_played": int(app.get("rt_last_played") or 0),
            "acquired": int(app.get("rt_time_acquired") or 0),
            "excluded": bool(app.get("exclude_reason")),
            "capsule": app.get("capsule_filename") or "",
        })
    return games


# -------------------------------------------------------------- Web API bits

def owned_games(apikey, steamid):
    data = _get("/IPlayerService/GetOwnedGames/v1/", {
        "key": apikey, "steamid": steamid,
        "include_appinfo": 1, "include_played_free_games": 1,
    }).get("response", {})
    return [{
        "appid": int(g["appid"]),
        "name": g.get("name") or ("App " + str(g["appid"])),
        "owners": [str(steamid)],
        "copies": 1,
        "playtime": int(g.get("playtime_forever") or 0),
        "last_played": int(g.get("rtime_last_played") or 0),
        "acquired": 0,
        "excluded": False,
        "capsule": "",
    } for g in data.get("games", []) if is_game(g["appid"], g.get("name"))]


def member_playtime(apikey, steamids):
    """Per-member playtime: {steamid: {appid: minutes}} plus a visibility note.

    Steam only serves another account's library when that person has set their
    game details to Public, so partial data is the normal case, not an error.
    """
    per, status = {}, {}
    for sid in steamids:
        sid = str(sid)
        try:
            games = owned_games(apikey, sid)
        except SteamError:
            per[sid], status[sid] = {}, "private"
            continue
        if not games:
            per[sid], status[sid] = {}, "private"
            continue
        mins = {str(g["appid"]): g["playtime"] for g in games if g["playtime"]}
        per[sid] = mins
        status[sid] = "ok" if mins else "hidden"
    return per, status


def player_names(apikey, steamids):
    """SteamID64 -> persona name. Best effort; blank dict if it fails."""
    out = {}
    ids = [str(s) for s in steamids if s]
    for i in range(0, len(ids), 100):
        chunk = ids[i:i + 100]
        try:
            data = _get("/ISteamUser/GetPlayerSummaries/v2/",
                        {"key": apikey, "steamids": ",".join(chunk)})
        except SteamError:
            continue
        for p in data.get("response", {}).get("players", []):
            out[str(p["steamid"])] = p.get("personaname") or str(p["steamid"])
    return out


# ------------------------------------------------------------------ Assembly

def build_library(cfg):
    """Merge every available source into one game list. Never raises: reports instead."""
    sources, warnings = [], []
    steamid = (cfg.get("steamid") or "").strip() or local_steamid()
    token = (cfg.get("access_token") or "").strip()
    apikey = (cfg.get("api_key") or "").strip()

    games, members = {}, {}

    if token and steamid:
        try:
            gid, raw_members, fam_name = family_group(token, steamid)
            for m in raw_members:
                sid = str(m.get("steamid"))
                members[sid] = {"steamid": sid, "name": sid, "role": m.get("role")}
            for g in family_library(token, gid, steamid):
                games[g["appid"]] = g
            sources.append((fam_name or "Steam Family") + " (" + str(len(members)) +
                           " members, " + str(len(games)) + " games)")
        except SteamError as exc:
            warnings.append(str(exc))
    elif token and not steamid:
        warnings.append("An access token is set but no SteamID64 - add one in Setup.")

    if apikey and steamid and not games:
        try:
            for g in owned_games(apikey, steamid):
                games[g["appid"]] = g
            members.setdefault(str(steamid), {"steamid": str(steamid), "name": str(steamid)})
            sources.append("Web API library (" + str(len(games)) + " games)")
        except SteamError as exc:
            warnings.append(str(exc))

    installed = scan_installed()
    if not games:
        for appid, g in installed.items():
            games[appid] = {
                "appid": appid, "name": g["name"], "owners": [str(steamid or "local")],
                "copies": 1, "playtime": 0, "last_played": g["last_played"],
                "acquired": 0, "excluded": False, "capsule": "",
            }
        if installed:
            sources.append("Local disk scan (" + str(len(installed)) + " installed games)")
    for appid in installed:
        if appid in games:
            games[appid]["installed"] = True

    per_player, pt_status = {}, {}
    if apikey and members:
        for sid, name in player_names(apikey, list(members)).items():
            if sid in members:
                members[sid]["name"] = name

        per_player, pt_status = member_playtime(apikey, list(members))
        for sid, st in pt_status.items():
            if sid in members:
                members[sid]["playtime_status"] = st
        hidden = [members[s]["name"] for s, st in pt_status.items()
                  if st != "ok" and s in members]
        if hidden:
            warnings.append(
                "Playtime is not public for " + ", ".join(sorted(hidden)) +
                " - they can share it via Steam privacy settings."
            )
    elif members and not apikey:
        warnings.append("No Web API key set, so family members show as raw SteamIDs.")

    # The signed-in account gets its name off disk, so at least one real name is
    # on screen even with no Web API key at all.
    if steamid:
        me = members.setdefault(str(steamid), {"steamid": str(steamid), "name": str(steamid)})
        if me["name"] == str(steamid):
            me["name"] = local_persona(steamid) or me["name"]
        me["is_local"] = True

    if not games:
        warnings.append("No games found from any source. Check Setup, or install some games.")

    out = sorted(games.values(), key=lambda g: g["name"].lower())
    for g in out:
        g.setdefault("installed", False)
        # who in the family has actually played this, and for how long
        by = {}
        for sid, mins in per_player.items():
            m = mins.get(str(g["appid"]))
            if m:
                by[sid] = m
        g["by_player"] = by
        if by:
            g["family_playtime"] = sum(by.values())
            g["playtime"] = max(g.get("playtime") or 0, g["family_playtime"])
        else:
            g["family_playtime"] = g.get("playtime") or 0

    payload = {
        "games": out,
        "members": sorted(members.values(), key=lambda m: m["name"].lower()),
        "sources": sources,
        "warnings": warnings,
        "fetched_at": int(time.time()),
        "token_expires": token_expiry(token) if token else 0,
    }
    try:
        os.makedirs(CACHE, exist_ok=True)
        with open(os.path.join(CACHE, "library.json"), "w", encoding="utf-8") as fh:
            json.dump(payload, fh)
    except OSError:
        pass
    return payload


def cached_library():
    try:
        with open(os.path.join(CACHE, "library.json"), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, json.JSONDecodeError):
        return None
