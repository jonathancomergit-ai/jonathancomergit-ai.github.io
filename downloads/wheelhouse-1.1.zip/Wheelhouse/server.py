"""Local web server for Wheelhouse. Serves the UI and proxies Steam."""
import json
import os
import socket
import threading
import urllib.error
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import steam
import tags as tagmod

HERE = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HERE, "web")
IMGCACHE = os.path.join(HERE, "cache", "img")
CONFIG = os.path.join(HERE, "config.json")

DEFAULT_CONFIG = {
    "steamid": "",
    "api_key": "",
    "access_token": "",
    "party_size": 4,
    "copy_rule": "strict",
    "capacity_rule": "on",
    "overrides": {},      # appid -> hand-set max players, wins over the derived cap
    "formats": {},        # appid -> hand-set versus/mixed/unfit, wins over the score
}

MIME = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".svg": "image/svg+xml",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".ico": "image/x-icon",
}

BLANK_PNG = bytes.fromhex(
    "89504e470d0a1a0a0000000d494844520000000100000001080600000"
    "01f15c4890000000a49444154789c6360000002000100ffff03000006"
    "000557bfabd40000000049454e44ae426082"
)

_lock = threading.Lock()

MAX_BODY = 64 * 1024   # config posts are a few hundred bytes


def _no_constants(name):
    # json.loads accepts NaN and Infinity by default; int() then blows up on them.
    raise ValueError("bad number: " + name)

# What each config key must look like. Anything else in a POST is dropped, so
# a bad value can never land in config.json and break the next start.
CONFIG_TYPES = {
    "steamid": str,
    "api_key": str,
    "access_token": str,
    "party_size": int,
    "copy_rule": str,
    "capacity_rule": str,
    "overrides": dict,
    "formats": dict,
}


def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        with open(CONFIG, encoding="utf-8") as fh:
            cfg.update(json.load(fh))
    except (OSError, json.JSONDecodeError):
        pass
    if not cfg.get("steamid"):
        cfg["steamid"] = steam.local_steamid() or ""
    return cfg


def save_config(patch):
    cfg = load_config()
    if not isinstance(patch, dict):
        return cfg
    for k in DEFAULT_CONFIG:
        if k in patch:
            v = patch[k]
            want = CONFIG_TYPES[k]
            if want is int and isinstance(v, bool):
                continue
            if isinstance(v, want):
                cfg[k] = v
    with open(CONFIG, "w", encoding="utf-8") as fh:
        json.dump(cfg, fh, indent=2)
    return cfg


_reclassified = False


def merge_tags(payload, cfg):
    """Fold genre/player-mode tags and hand-set overrides into the game list."""
    global _reclassified
    db = tagmod.load()
    apps = db.get("apps") or {}

    # A tagging run holds its own copy of the classifier, so records written by
    # an older build can lack newer fields. Recompute them from the stored raw
    # data once the run is finished - never mid-run, or we would race its writes.
    if apps and not _reclassified and not (db.get("progress") or {}).get("running"):
        if any("cap_basis" not in r or "format" not in r for r in apps.values()):
            tagmod.save(tagmod.reclassify(db))
        _reclassified = True
    overrides = cfg.get("overrides") or {}
    counts = {}

    for g in payload.get("games", []):
        rec = apps.get(str(g["appid"])) or {}
        g["cats"] = rec.get("cats") or []
        g["modes"] = rec.get("modes") or []
        g["solo_only"] = bool(rec.get("solo_only"))
        g["tagged"] = bool(rec)
        ov = overrides.get(str(g["appid"]))
        try:
            ov = int(ov or 0)
        except (TypeError, ValueError, OverflowError):
            ov = 0
        if ov > 0:
            g["max_players"] = ov
            g["cap_basis"] = "manual"
        else:
            g["max_players"] = rec.get("max_players") or 0
            g["cap_basis"] = rec.get("cap_basis") or ""

        # Does playing this produce a winner? See tags.score_format.
        g["format"] = rec.get("format") or ""
        g["versus_score"] = rec.get("versus_score")
        g["win_cond"] = rec.get("win_cond") or ""
        fov = (cfg.get("formats") or {}).get(str(g["appid"]))
        if fov:
            g["format"] = fov
            g["format_manual"] = True
            if fov == "mixed" and not g["win_cond"]:
                g["win_cond"] = tagmod.DEFAULT_WIN_RULE
        for c in g["cats"]:
            counts[c] = counts.get(c, 0) + 1

    payload["categories"] = [
        {"name": c, "count": counts[c]}
        for c in sorted(counts, key=lambda c: -counts[c])
    ]
    payload["tag_progress"] = db.get("progress")
    payload["tagged_count"] = len(apps)
    return payload


def autotag(payload):
    """Tag anything new in the background.

    Nothing used to trigger this but a hand-made POST, so a fresh install
    imported its library and then sat on an empty category screen. Tagging is
    incremental and skips what it already has, so the common case here is that
    it finds nothing to do and returns.
    """
    db = tagmod.load()
    if (db.get("progress") or {}).get("running"):
        return
    have = db.get("apps") or {}
    todo = [g["appid"] for g in payload.get("games", []) if str(g["appid"]) not in have]
    if todo:
        start_tagging(todo)


def start_tagging(appids):
    """Kick the (slow, rate-limited) enrichment off in the background."""
    def run():
        try:
            tagmod.enrich(appids)
            tagmod.save(tagmod.reclassify(tagmod.load()))
        except Exception:
            pass
    t = threading.Thread(target=run, daemon=True)
    t.start()
    return t


def fetch_header(appid):
    """Cache Steam capsule art on disk so game night works even if the CDN hiccups."""
    os.makedirs(IMGCACHE, exist_ok=True)
    path = os.path.join(IMGCACHE, str(appid) + ".jpg")
    miss = os.path.join(IMGCACHE, str(appid) + ".miss")
    if os.path.isfile(path):
        with open(path, "rb") as fh:
            return fh.read(), "image/jpeg"
    if os.path.isfile(miss):
        return BLANK_PNG, "image/png"
    urls = [
        "https://cdn.cloudflare.steamstatic.com/steam/apps/%s/header.jpg" % appid,
        "https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/%s/header.jpg" % appid,
    ]
    for url in urls:
        try:
            req = urllib.request.Request(url, headers=steam.UA)
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = resp.read()
            if data:
                with open(path, "wb") as fh:
                    fh.write(data)
                return data, "image/jpeg"
        except (urllib.error.URLError, OSError):
            continue
    try:
        open(miss, "wb").close()
    except OSError:
        pass
    return BLANK_PNG, "image/png"


class Handler(BaseHTTPRequestHandler):
    server_version = "Wheelhouse"

    def log_message(self, fmt, *args):
        pass

    # ---------------------------------------------------------- replies

    def _send(self, code, body, ctype, cache=False):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control",
                         "public, max-age=86400" if cache else "no-store")
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj), MIME[".json"])

    def _static(self, rel):
        rel = rel.lstrip("/") or "index.html"
        path = os.path.normpath(os.path.join(WEB, rel))
        if not path.startswith(WEB + os.sep) or not os.path.isfile(path):
            return self._send(404, "Not found", "text/plain; charset=utf-8")
        ext = os.path.splitext(path)[1].lower()
        with open(path, "rb") as fh:
            self._send(200, fh.read(), MIME.get(ext, "application/octet-stream"))

    # ------------------------------------------------------------ guards

    def _local_host(self):
        """Only answer requests addressed to this machine by name.

        Stops DNS rebinding: a web page whose domain is pointed at 127.0.0.1
        still sends its own domain in the Host header, so it gets a 403.
        """
        host = (self.headers.get("Host") or "").lower()
        port = str(self.server.server_address[1])
        return host in ("127.0.0.1:" + port, "localhost:" + port)

    def _same_origin(self):
        """POSTs must come from Wheelhouse's own page, as JSON.

        Browsers always send Origin on a cross-site POST, and they cannot send
        Content-Type: application/json across sites without a preflight that
        this server never approves. Either check alone stops another website
        from changing your settings; both together cost nothing.
        """
        ctype = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if ctype != "application/json":
            return False
        origin = self.headers.get("Origin")
        if origin is None:
            return True
        port = str(self.server.server_address[1])
        return origin.lower() in ("http://127.0.0.1:" + port, "http://localhost:" + port)

    # ------------------------------------------------------------ routes

    def do_GET(self):
        if not self._local_host():
            return self._send(403, "Forbidden", "text/plain; charset=utf-8")
        url = urlparse(self.path)
        route = url.path
        query = parse_qs(url.query)

        if route == "/api/config":
            cfg = load_config()
            return self._json({
                "steamid": cfg["steamid"],
                "party_size": cfg["party_size"],
                "copy_rule": cfg["copy_rule"],
                "has_api_key": bool(cfg["api_key"]),
                "has_token": bool(cfg["access_token"]),
                "token_expires": steam.token_expiry(cfg["access_token"]),
            })

        if route == "/api/library":
            fresh = query.get("refresh", ["0"])[0] == "1"
            cfg = load_config()
            payload = None
            if not fresh:
                cached = steam.cached_library()
                if cached:
                    cached["from_cache"] = True
                    payload = cached
            if payload is None:
                with _lock:
                    payload = steam.build_library(cfg)
                payload["from_cache"] = False
            autotag(payload)
            return self._json(merge_tags(payload, cfg))

        if route == "/api/tags":
            db = tagmod.load()
            return self._json({
                "progress": db.get("progress"),
                "tagged": len(db.get("apps") or {}),
                "updated": db.get("updated", 0),
                "all_categories": tagmod.CATEGORY_NAMES,
            })

        if route.startswith("/api/img/"):
            appid = route.rsplit("/", 1)[-1]
            if not appid.isdigit():
                return self._send(404, "bad appid", "text/plain; charset=utf-8")
            data, ctype = fetch_header(appid)
            return self._send(200, data, ctype, cache=True)

        return self._static(route)

    def do_POST(self):
        if not self._local_host() or not self._same_origin():
            return self._send(403, "Forbidden", "text/plain; charset=utf-8")
        route = urlparse(self.path).path
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n < 0 or n > MAX_BODY:
                return self._json({"error": "body too large"}, 413)
            body = json.loads(self.rfile.read(n) or b"{}", parse_constant=_no_constants)
        except (ValueError, json.JSONDecodeError):
            return self._json({"error": "bad JSON"}, 400)
        if not isinstance(body, dict):
            return self._json({"error": "bad JSON"}, 400)

        if route == "/api/quit":
            self._json({"ok": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
            return None

        if route == "/api/config":
            cfg = save_config(body)
            return self._json({"ok": True, "steamid": cfg["steamid"]})

        if route == "/api/override":
            """Hand-set max players for one game; 0/absent clears it."""
            appid = str(body.get("appid") or "")
            if not appid.isdigit():
                return self._json({"error": "bad appid"}, 400)
            cfg = load_config()
            ov = dict(cfg.get("overrides") or {})
            try:
                n = int(body.get("max_players") or 0)
            except (TypeError, ValueError, OverflowError):
                return self._json({"error": "bad max_players"}, 400)
            if n > 0:
                ov[appid] = n
            else:
                ov.pop(appid, None)
            save_config({"overrides": ov})
            return self._json({"ok": True, "overrides": len(ov)})

        if route == "/api/format":
            """Hand-set whether a game works as a bracket match; "" clears it."""
            appid = str(body.get("appid") or "")
            if not appid.isdigit():
                return self._json({"error": "bad appid"}, 400)
            fmt = str(body.get("format") or "")
            if fmt not in ("", "versus", "mixed", "unfit"):
                return self._json({"error": "bad format"}, 400)
            cfg = load_config()
            fm = dict(cfg.get("formats") or {})
            if fmt:
                fm[appid] = fmt
            else:
                fm.pop(appid, None)
            save_config({"formats": fm})
            return self._json({"ok": True, "formats": len(fm)})

        if route == "/api/tags/refresh":
            cached = steam.cached_library() or {}
            ids = [g["appid"] for g in cached.get("games", [])]
            db = tagmod.load()
            if (db.get("progress") or {}).get("running"):
                return self._json({"ok": True, "already": True})
            start_tagging(ids)
            return self._json({"ok": True, "queued": len(ids)})

        return self._send(404, "Not found", "text/plain; charset=utf-8")


def free_port(preferred=8731):
    for port in (preferred, 0):
        try:
            s = socket.socket()
            s.bind(("127.0.0.1", port))
            got = s.getsockname()[1]
            s.close()
            return got
        except OSError:
            continue
    return preferred


def main():
    port = free_port()
    url = "http://127.0.0.1:%d/" % port
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print("=" * 58)
    print("  WHEELHOUSE  ->  " + url)
    print("  Close this window to stop the app.")
    print("=" * 58)
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
